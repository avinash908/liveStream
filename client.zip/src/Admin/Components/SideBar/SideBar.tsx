import { AccountCircle, Category, Flag, Home, Inbox } from '@mui/icons-material';
import { Box, List, ListItemIcon, ListItemText, makeStyles } from '@mui/material/';
import { Link } from "react-router-dom";
import './style.css'
const structure = [
  { id: 0, label: 'Dashboard', link: '/admin/dashboard', icon: <Home /> },
  { id: 1, label: 'Users', link: '/admin/dashboard/users', icon: <AccountCircle /> },
  { id: 2, label: 'Country', link: '/admin/dashboard/country', icon: <Flag /> },
  { id: 3, label: 'Category', link: '/admin/dashboard/category', icon: <Category /> },
  { id: 3, label: 'Sub Category', link: '/admin/dashboard/sub-category', icon: <Category /> },

];

function SideBar() {
  return (
    <Box>
      <List style={{ padding: "30px" }} className={""}>
        {structure.map(link => {
          return <Link
            key={link.id}
            to={link.link}
            style={{
              display: 'flex',
              alignItems: "center",
              justifyContent: "cente",
              marginBlock: 10,
              borderRadius: 5,
              textDecoration: 'none',
              color: "#ccc"
            }}
            className='linkHover'
          >
            <ListItemIcon
              className={""}
              color='#ccc'
              style={{ color: "#ccc", minWidth: "auto" }}
            >
              {link.icon ? link.icon : <Inbox />}
            </ListItemIcon>
            <Box sx={{ marginInline: 1 }}></Box>
            <ListItemText
              classes={{}}
              primary={link.label}
            />
          </Link>
        })}
      </List>
    </Box>
  )
}

export default SideBar


