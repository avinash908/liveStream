import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import * as React from 'react';
import { TableComponents, TableVirtuoso } from 'react-virtuoso';
import { AreaType, CityType, CountryType, StateType, UserType } from '../../../context/@Types/AppContextType';
import { Delete, Edit, RemoveRedEye, TableView, ViewArray } from '@mui/icons-material';
import './style.css'
import DeleteModal from '../DeleteModal/DeleteModal';
import { AppContext } from '../../../context/AppContext';
import { Button } from '@mui/material';

interface ColumnData {
    dataKey: keyof UserType;
    label: string;
    numeric?: boolean;
    width: number;
}


const VirtuosoTableComponents: TableComponents<UserType | CountryType | any> = {
    Scroller: React.forwardRef<HTMLDivElement>((props, ref) => (
        <TableContainer component={Paper} {...props} ref={ref} />
    )),
    Table: (props) => (
        <Table {...props} sx={{ borderCollapse: 'separate', tableLayout: 'fixed' }} />
    ),
    TableHead,
    TableRow: ({ item: _item, ...props }) => <TableRow {...props} />,
    TableBody: React.forwardRef<HTMLTableSectionElement>((props, ref) => (
        <TableBody {...props} ref={ref} />
    )),
};

function fixedHeaderContent(columns: Array<ColumnData>) {
    return (
        <TableRow>
            {columns.map((column) => (
                <TableCell
                    key={column.dataKey}
                    variant="head"
                    align={column.numeric || false ? 'right' : 'left'}
                    style={{ width: column.width }}
                    sx={{
                        backgroundColor: 'background.paper',
                    }}
                >
                    {column.label}
                </TableCell>
            ))}
        </TableRow>
    );
}
interface TableType {
    type: "USER" | "COUNTRY" | "CATEGORY" | "SUBCATEGORY" | "STATE" | "CITY" | "AREA"
}
interface TableProps {
    header: Array<ColumnData>,
    data: Array<UserType | CountryType | any>,
    tableType: TableType

}



export default function ReactVirtualizedTable({ header, data, tableType }: TableProps) {
    const appContext = React.useContext(AppContext);
    const [open, setOpen] = React.useState(false);
    const [id, setId] = React.useState("");

    const onConfirm = () => {
        if (id === "") {
            alert("Please Relode Web Page");
        } else {
            alert(id);
        }
    }


    function rowContent(_index: number, row: UserType | CountryType | StateType | CityType | AreaType | null) {
        switch (tableType.type) {
            case "USER":
                return onCreateUserRow(row as UserType, _index);
            case "COUNTRY":
                return onCreateCountryRow(row as CountryType, _index);
            case "STATE":
                return onCreateStateRow(row as StateType, _index);
            case "CITY":
                return onCreateCityRow(row as CityType, _index);
            case "AREA":
                return onCreateArea(row as AreaType, _index);
            case "CATEGORY":
                return onCreateCategoryRow(row, _index);
            case "SUBCATEGORY":
                return onCreateSubCategoryRow(row, _index);
            default:
                return <p>Not Data Founded</p>
        }
    }


    const onCreateUserRow = (user: UserType, index: number) => {
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.username}>
                    {user.username}
                </TableCell>
                <TableCell
                    key={user.email}>
                    {user.email}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "error"}
                    >
                        {user.status ? "Active" : "Inactive"}
                    </Button>
                </TableCell>
                <TableCell>
                    {user.address?.country == "" ? "Not Added" : user.address?.country}
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateCategoryRow = (user: any, index: number) => {
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.title}>
                    {user.title}
                </TableCell>
                <TableCell
                    key={user.description}>
                    {user.description}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "error"}
                    >
                        {user.status ? "Active" : "Inactive"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateStateRow = (user: StateType, index: number) => {
        var country = appContext?.allFetchCountries == null ? null : appContext?.allFetchCountries?.filter(v => v._id?.includes(user.countryId) ? v : null)[0] ?? null;
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.state}>
                    {user.state}
                </TableCell>
                <TableCell
                    key={user.countryId}>
                    {country?.country}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "error"}
                    >
                        {user.status ? "Active" : "Inactive"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id!);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateCityRow = (user: CityType, index: number) => {
        var country = appContext?.allFetchCountries == null ? null : appContext?.allFetchCountries?.filter(v => v._id?.includes(user.countryId) ? v : null)[0] ?? null;
        var state = appContext?.allFetchStates == null ? null : appContext?.allFetchStates?.filter(v => v._id?.includes(user.stateId) ? v : null)[0] ?? null;
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.city}>
                    {user.city}
                </TableCell>
                <TableCell
                    key={user.stateId}>
                    {state?.state}
                </TableCell>
                <TableCell
                    key={user.countryId}>
                    {country?.country}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "error"}
                    >
                        {user.status ? "Active" : "Inactive"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id!);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateArea = (user: AreaType, index: number) => {
        var country = appContext?.allFetchCountries == null ? null : appContext?.allFetchCountries?.filter(v => v._id == user.countryId ? v : null)[0] ?? null;
        var state = appContext?.allFetchStates == null ? null : appContext?.allFetchStates?.filter(v => v._id == user.stateId ? v : null)[0] ?? null;
        var city = appContext?.allFetchCites == null ? null : appContext?.allFetchCites?.filter(v => v._id == user.cityId ? v : null)[0] ?? null;

        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.area}>
                    {user.area}
                </TableCell>
                <TableCell
                    key={user.cityId}>
                    {city?.city}
                </TableCell>
                <TableCell
                    key={user.stateId}>
                    {state?.state}
                </TableCell>
                <TableCell
                    key={user.countryId}>
                    {country?.country}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "error"}
                    >
                        {user.status ? "Active" : "Inactive"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id!);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateSubCategoryRow = (user: any, index: number) => {
        const category = appContext?.allFetchCategory?.filter(v => v._id == user.categoryId ? v : null);
        console.log(category);
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.title}>
                    {user.title}
                </TableCell>
                <TableCell
                    key={user.description}>
                    {user.description}
                </TableCell>
                <TableCell>
                    {category && category[0].title}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "info"}
                    >
                        {user.status ? "Active" : "Suspended"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }
    const onCreateCountryRow = (user: CountryType, index: number) => {
        return (
            <React.Fragment>
                <TableCell
                    key={user._id}>
                    {index + 1}
                </TableCell>
                <TableCell
                    key={user.country}>
                    {user.country}
                </TableCell>
                <TableCell>
                    <Button
                        variant="contained"
                        color={user.status ? "success" : "info"}
                    >
                        {user.status ? "Active" : "Suspended"}
                    </Button>
                </TableCell>
                <TableCell>
                    <RemoveRedEye sx={{ cursor: "pointer" }} />
                    <Edit sx={{ cursor: "pointer" }} />
                    <Delete onClick={() => {
                        setId(user._id!);
                        setOpen(true);
                    }} sx={{ cursor: "pointer" }} />
                </TableCell>
            </React.Fragment>
        );
    }

    return (
        <Paper style={{ height: 400, width: '100%' }}>
            <TableVirtuoso
                data={data}
                components={VirtuosoTableComponents}
                fixedHeaderContent={() => fixedHeaderContent(header)}
                itemContent={rowContent}
            />
            <DeleteModal onConfirm={onConfirm} open={open} onClose={() => setOpen(false)} />
        </Paper>
    );
}