import { TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';
import * as React from 'react';
import './style.css';
import { AppContext } from '../../../context/AppContext';
const Transition = React.forwardRef(function Transition(
    props: TransitionProps & {
        children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>,
) {
    return <Slide direction="down" ref={ref} {...props} />;
});

interface FIeldsType {
    input?: Array<string>,
    dorpdown?: Array<Object>
}

interface MoadlType {
    onShowModal?: () => void,
    open: boolean,
    onClose: () => void,
    title: string,
    fields: FIeldsType,
    onSubmit?: (data: any) => Promise<boolean>,
    type?: string,
}

export default function AlertDialogSlide({ open, onClose, title, fields, onSubmit, type = "all" }: MoadlType) {
    const [loader, setLoader] = React.useState(false);
    const appContext = React.useContext(AppContext);
    if (type == "city" || type == 'state' || type == "area") {
        return (
            <Dialog
                open={open}
                TransitionComponent={Transition}
                keepMounted
                onClose={onClose}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle color={"white"}>{title}</DialogTitle>
                <form onSubmit={async (event) => {
                    event.preventDefault();
                    const data = new FormData(event.target as HTMLFormElement);
                    console.log(data.get("Username"));
                    var object: any = {};
                    data.forEach(function (value, key) {
                        if (key == "User Type") {
                            object['userType'] = value;
                        } else if (key == 'Zip Code') {
                            object['zipCode'] = value;

                        } else {
                            object[key.toLocaleLowerCase()] = value;
                        }
                    });
                    setLoader(true);
                    var isSuccess = await onSubmit!(object);
                    console.log(isSuccess);
                    setLoader(false);
                    if (isSuccess) {
                        onClose();
                    }
                }}>
                    <DialogContent>
                        {
                            fields.dorpdown &&
                            fields.dorpdown?.map((v: any, k) => {
                                const option = Object.keys(v).map(item => item);

                                return <div key={k}>
                                    <select

                                        onChange={(e) => {
                                            if (e.target.name == "Country") {
                                                appContext?.setCountryId!(e.target.value);
                                            }else if(e.target.name == "State"){
                                                appContext?.setStateId!(e.target.value);
                                            }
                                        }}
                                        name={option[0]} style={{
                                            width: "100%",
                                            height: 50,
                                            outline: 'none',
                                            background: "transparent",
                                            borderColor: "#cccccc35",
                                            borderRadius: 4,
                                            marginBlock: 6,
                                            color: "#777",
                                            paddingLeft: 10,
                                        }}>
                                        <option selected>
                                            Select {option[0]}
                                        </option>
                                        {v[option[0]].map((value: any, i: number) => {
                                            const val = value instanceof Object ? value.value : value;
                                            const keyValue = value instanceof Object ? value.id : value;
                                            if (val != null) {
                                                return <option value={keyValue} key={i}>
                                                    {val}
                                                </option>
                                            }
                                        })}
                                    </select>
                                </div>
                            })
                        }
                        {fields.input &&
                            fields.input?.map((v, k) => {
                                return <div key={k}>
                                    <TextField
                                        name={v}
                                        placeholder={`Enter ${v}`} sx={{
                                            width: "100%"
                                        }}
                                        InputProps={{
                                            sx: {
                                                color: "#fff",
                                                outlineColor: "green",
                                                marginBlock: 1
                                            },
                                            style: {
                                                color: "#fff",
                                                outlineColor: "green"
                                            },
                                            classes: {
                                                notchedOutline: "outlineStyle",
                                            },
                                        }}
                                    />
                                </div>
                            })
                        }

                    </DialogContent>
                    <DialogActions>
                        <Button onClick={onClose}
                            variant="contained" sx={{
                                borderColor: "green",
                                marginX: 2,
                                color: "#111",
                                outline: "none",
                                backgroundColor: "#ccc",
                                ":hover": { background: "#777", borderColor: "#777", color: "#fff" }
                            }}
                        >Close</Button>
                        <Button type="submit" variant="outlined" sx={{
                            borderColor: "green",
                            marginX: 2,
                            color: "#fff",
                            outline: "none",
                            ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
                        }} >{loader ? "Please Wait..." : "Submit"}</Button>
                    </DialogActions>
                </form>
            </Dialog>
        );
    }
    return (
        <Dialog
            open={open}
            TransitionComponent={Transition}
            keepMounted
            onClose={onClose}
            aria-describedby="alert-dialog-slide-description"
        >
            <DialogTitle color={"white"}>{title}</DialogTitle>
            <form onSubmit={async (event) => {
                event.preventDefault();
                const data = new FormData(event.target as HTMLFormElement);
                console.log(data.get("Username"));
                var object: any = {};
                data.forEach(function (value, key) {
                    if (key == "User Type") {
                        object['userType'] = value;
                    } else if (key == 'Zip Code') {
                        object['zipCode'] = value;

                    } else {
                        object[key.toLocaleLowerCase()] = value;
                    }
                });
                setLoader(true);
                var isSuccess = await onSubmit!(object);
                console.log(isSuccess);
                setLoader(false);
                if (isSuccess) {
                    onClose();
                }
            }}>
                <DialogContent>
                    {fields.input &&
                        fields.input?.map((v, k) => {
                            return <div key={k}>
                                <TextField
                                    name={v}
                                    placeholder={`Enter ${v}`} sx={{
                                        width: "100%"
                                    }}
                                    InputProps={{
                                        sx: {
                                            color: "#fff",
                                            outlineColor: "green",
                                            marginBlock: 1
                                        },
                                        style: {
                                            color: "#fff",
                                            outlineColor: "green"
                                        },
                                        classes: {
                                            notchedOutline: "outlineStyle",
                                        },
                                    }}
                                />
                            </div>
                        })
                    }
                    {
                        fields.dorpdown &&
                        fields.dorpdown?.map((v: any, k) => {
                            const option = Object.keys(v).map(item => item);
                            return <div key={k}>
                                <select name={option[0]} style={{
                                    width: "100%",
                                    height: 50,
                                    outline: 'none',
                                    background: "transparent",
                                    borderColor: "#cccccc35",
                                    borderRadius: 4,
                                    marginBlock: 6,
                                    color: "#777",
                                    paddingLeft: 10,
                                }}>
                                    <option selected>
                                        Select {option[0]}
                                    </option>
                                    {v[option[0]].map((value: any, i: number) => {
                                        const val = value instanceof Object ? value.value : value;
                                        const keyValue = value instanceof Object ? value.id : value;
                                        return <option value={keyValue} key={i}>
                                            {val}
                                        </option>
                                    })}
                                </select>
                            </div>
                        })
                    }
                </DialogContent>
                <DialogActions>
                    <Button onClick={onClose}
                        variant="contained" sx={{
                            borderColor: "green",
                            marginX: 2,
                            color: "#111",
                            outline: "none",
                            backgroundColor: "#ccc",
                            ":hover": { background: "#777", borderColor: "#777", color: "#fff" }
                        }}
                    >Close</Button>
                    <Button type="submit" variant="outlined" sx={{
                        borderColor: "green",
                        marginX: 2,
                        color: "#fff",
                        outline: "none",
                        ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
                    }} >{loader ? "Please Wait..." : "Submit"}</Button>
                </DialogActions>
            </form>

        </Dialog>
    );
}