import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Box,
    IconButton,
    Typography,
} from '@mui/material';
import { Close } from '@mui/icons-material';
import './style.css'
interface DeleteModalType {
    open: boolean,
    onClose: () => void,
    onConfirm:()=>void,
}

const DeleteModal = ({ open, onClose,onConfirm }: DeleteModalType) => {
    return (
        <Dialog open={open} maxWidth="sm" fullWidth>
            <DialogTitle>Confirm</DialogTitle>
            <Box position="absolute" top={0} right={0}>
                <IconButton onClick={onClose}>
                    <Close sx={{ color: "white" }} />
                </IconButton>
            </Box>
            <DialogContent>
                <Typography>Do you want to delete this record from your Database</Typography>
            </DialogContent>
            <DialogActions>
                <Button sx={{ color: "black" }} onClick={onClose} color="inherit" variant="contained">
                    Cancel
                </Button>
                <Button onClick={onConfirm} color="error" variant="contained">
                    Confirm
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default DeleteModal;
