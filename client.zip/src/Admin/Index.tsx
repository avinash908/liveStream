import { useEffect, useState } from 'react';
import AppLoader from '../Assets/Svg/appLoader.svg';

function Index() {
    const [isLogin, setIsLogin] = useState(true);
    useEffect(() => {
        var user = window.localStorage.getItem("@authUser");
        if (user != null) {
            setIsLogin(false);
            window.location.replace("/");
        } else {
            setIsLogin(false);
            window.location.replace("/admin/login");
        }
    }, []);
    return (
        <div>
            {isLogin ? <div style={{
                width: "100%",
                display: "flex",
                alignItems: 'center',
                justifyContent: "center",
                height: "100vh",
                background: "#0B1416"
            }}>
                <img src={AppLoader} />
            </div> : null}
        </div>
    )
}

export default Index