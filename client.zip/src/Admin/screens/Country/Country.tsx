import { Search } from '@mui/icons-material';
import { Box, Button, InputAdornment, Tab, Tabs, TextField, Typography } from '@mui/material';
import { useContext, useState } from 'react';
import { AppContext } from '../../../context/AppContext';
import ReactVirtualizedTable from '../../Components/Table/Table';
import AlertDialogSlide from '../../Components/Modal/Modal';
import '../../style.css';

const columns: any = [
  {
    width: 200,
    label: 'id',
    dataKey: '_id',
  },
  {
    width: 120,
    label: 'Country',
    dataKey: 'country',
  },
  {
    width: 120,
    label: 'Status',
    dataKey: 'status',
  },
  {
    width: 120,
    label: 'Action',
    dataKey: 'action',
  },
];
const stateColumn: any = [
  {
    width: 200,
    label: 'id',
    dataKey: '_id',
  },
  {
    width: 120,
    label: 'State',
    dataKey: 'state',
  },
  {
    width: 120,
    label: 'Country',
    dataKey: 'country',
  },
  {
    width: 120,
    label: 'Status',
    dataKey: 'status',
  },
  {
    width: 120,
    label: 'Action',
    dataKey: 'action',
  },
];
const cityColumn: any = [
  {
    width: 200,
    label: 'id',
    dataKey: '_id',
  },
  {
    width: 120,
    label: 'City',
    dataKey: 'city',
  },
  {
    width: 120,
    label: 'State',
    dataKey: 'state',
  },
  {
    width: 120,
    label: 'Country',
    dataKey: 'country',
  },
  {
    width: 120,
    label: 'Status',
    dataKey: 'status',
  },
  {
    width: 120,
    label: 'Action',
    dataKey: 'action',
  },
];
const AreaColumn: any = [
  {
    width: 200,
    label: 'id',
    dataKey: '_id',
  },
  {
    width: 120,
    label: 'Area',
    dataKey: 'area',
  },
  {
    width: 120,
    label: 'City',
    dataKey: 'city',
  },
  {
    width: 120,
    label: 'State',
    dataKey: 'state',
  },
  {
    width: 120,
    label: 'Country',
    dataKey: 'country',
  },
  {
    width: 120,
    label: 'Status',
    dataKey: 'status',
  },
  {
    width: 120,
    label: 'Action',
    dataKey: 'action',
  },
];
function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}




function Country() {
  const appContext = useContext(AppContext);
  const [open, setOpen] = useState(false);


  const [value, setValue] = useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };


  return (
    <div>
      <Box sx={{ borderBottom: 0, borderColor: 'divider' }}>
        <Tabs value={value} onChange={handleChange}
          textColor="inherit"
          aria-label="basic tabs example">
          <Tab label="Country" {...a11yProps(0)} />
          <Tab label="State" {...a11yProps(1)} />
          <Tab label="City" {...a11yProps(2)} />
          <Tab label="Area" {...a11yProps(3)} />
        </Tabs>
      </Box>
      <Box
        sx={{
          paddingTop: 5,
          paddingLeft: 5,
          display: "flex",
          alignItems: 'center',
          justifyContent: "space-between"
        }}
      >
        <Typography fontSize={25} color={"white"} fontWeight={600} py={3}>{value == 0 ? "Country" : value == 1 ? "State" : value == 2 ? "City" : "Area"}</Typography>
        <Button
          onClick={() => { setOpen(true) }}
          variant="outlined" sx={{
            borderColor: "green",
            marginX: 2,
            color: "#fff",
            outline: "none",
            ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
          }} >
          Add New
        </Button>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <Box sx={{
          paddingLeft: 1,
          paddingRight: 1,
        }}>
          {appContext?.allFetchCountries == null ? <p style={{
            fontSize: '20px',
            textAlign: "center",
            color: "white"
          }}>Please wait...</p> : <ReactVirtualizedTable
            tableType={{ type: "COUNTRY" }}
            header={columns} data={appContext?.allFetchCountries} />}

        </Box>
        <AlertDialogSlide
          title='Add Country'
          open={open}
          fields={{
            input: ["Country"],
            dorpdown: [
              {
                "Status": ["Active", "InActive"]
              }
            ]
          }}
          onClose={() => setOpen(false)}
          onSubmit={appContext?.onCountrySubmit}
        />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <Box sx={{
          paddingLeft: 1,
          paddingRight: 1,
        }}>
          {appContext?.allFetchStates == null ? <p style={{
            fontSize: '20px',
            textAlign: "center",
            color: "white"
          }}>Please wait...</p> : <ReactVirtualizedTable
            tableType={{ type: "STATE" }}
            header={stateColumn} data={appContext?.allFetchStates} />}

        </Box>
        <AlertDialogSlide
          title='Add State'
          open={open}
          type='state'
          fields={{
            input: ["State"],
            dorpdown: [
              {
                "Country": appContext?.allFetchCountries?.map(v => ({ "value": v.country, "id": v._id }))
              },
              {
                "Status": ["Active", "InActive"]
              }
            ]
          }}
          onClose={() => setOpen(false)}
          onSubmit={appContext?.onStateSubmit}
        />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={2}>
        <Box sx={{
          paddingLeft: 1,
          paddingRight: 1,
        }}>
          {appContext?.allFetchCites == null ? <p style={{
            fontSize: '20px',
            textAlign: "center",
            color: "white"
          }}>Please wait...</p> : <ReactVirtualizedTable
            tableType={{ type: "CITY" }}
            header={cityColumn} data={appContext?.allFetchCites} />}

        </Box>
        <AlertDialogSlide
          title='Add City'
          type='city'
          open={open}
          fields={{
            input: ["City"],
            dorpdown: [
              {
                "Country": appContext?.allFetchCountries?.map(v => ({ "value": v.country, "id": v._id }))
              },
              {
                "State": appContext?.allFetchStates?.map(v => v.countryId == appContext.countryId ? ({ "value": v.state, "id": v._id }) : null)
              },
              {
                "Status": ["Active", "InActive"]
              }
            ]
          }}
          onClose={() => setOpen(false)}
          onSubmit={appContext?.onCitySubmit}
        />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={3}>
        <Box sx={{
          paddingLeft: 1,
          paddingRight: 1,
        }}>
          {appContext?.allFetchArea == null ? <p style={{
            fontSize: '20px',
            textAlign: "center",
            color: "white"
          }}>Please wait...</p> : <ReactVirtualizedTable
            tableType={{ type: "AREA" }}
            header={AreaColumn} data={appContext?.allFetchArea} />}

        </Box>
        <AlertDialogSlide
          title='Add Area'
          open={open}
          type='area'
          fields={{
            input: ["Area"],
            dorpdown: [
              {
                "Country": appContext?.allFetchCountries?.map(v => ({ "value": v.country, "id": v._id }))
              },
              {
                "State": appContext?.allFetchStates?.map(v => v.countryId == appContext.countryId ? ({ "value": v.state, "id": v._id }) : null)
              },
              {
                "City": appContext?.allFetchCites?.map(v => v.stateId == appContext.stateId ? ({ "value": v.city, "id": v._id }) : null)
              },
              {
                "Status": ["Active", "InActive"]
              }
            ]
          }}
          onClose={() => setOpen(false)}
          onSubmit={appContext?.onAreaSubmit}
        />
      </CustomTabPanel>
    </div>
  )
}

export default Country