import { Search } from '@mui/icons-material'
import { Box, Button, InputAdornment, TextField, Typography } from '@mui/material'
import './user.css'
import ReactVirtualizedTable from '../../Components/Table/Table'
import { useContext, useState } from 'react';
import { AppContext } from '../../../context/AppContext';
import AlertDialogSlide from '../../Components/Modal/Modal';



const columns: any = [
  {
    width: 200,
    label: 'id',
    dataKey: '_id',
  },
  {
    width: 120,
    label: 'Username',
    dataKey: 'username',
  },
  {
    width: 120,
    label: 'Email',
    dataKey: 'email',
  },
  {
    width: 120,
    label: 'Status',
    dataKey: 'status',
  },
  {
    width: 120,
    label: 'Country',
    dataKey: 'country',
  },
  {
    width: 120,
    label: 'Action',
    dataKey: 'action',
  },

];

function User() {
  const [open, setOpen] = useState(false);

  const appContext = useContext(AppContext);
  return (
    <div>
      <Box
        sx={{
          paddingTop: 5,
          paddingLeft: 5,
          display: "flex",
          alignItems: 'center',
          justifyContent: "space-between"
        }}
      >
        {/* <TextField
          id="input-with-icon-textfield"
          label="Search"
          sx={{
            visibility: "hidden"
          }}
          InputLabelProps={{
            classes: {
              formControl: "lebal"
            }
          }}
          style={{ width: "40%", borderColor: "#fff" }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search sx={{ color: "#ccc" }} />
              </InputAdornment>
            ),
            classes: {
              notchedOutline: "outlineStyle",
            },
            sx: {
              color: "#fff"
            }
          }}
          variant="outlined"
        /> */}
        <Typography fontSize={25} color={"white"} fontWeight={600} py={3}>Users</Typography>
        <Button
          onClick={() => setOpen(true)}
          variant="outlined" sx={{
            borderColor: "green",
            marginX: 2,
            color: "#fff",
            outline: "none",
            ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
          }} >
          Add New
        </Button>
      </Box>
      <Box sx={{
        paddingLeft: 5,
        paddingRight: 5,
        marginBlock: 10
      }}>
        {appContext?.allFetchUsers == null ? <p>Please wait...</p> : <ReactVirtualizedTable
          tableType={{ type: "USER" }}
          header={columns} data={appContext?.allFetchUsers} />}
      </Box>
      <AlertDialogSlide
        open={open}
        onClose={() => { setOpen(false) }}
        title='Add User'
        fields={{
          input: ["Username", "Email", "Password", 'Address', 'City', "State", "Zip Code", 'Country'],
          dorpdown: [
            {
              "User Type": [
                "Admin",
                "User"
              ],
            },
            {
              "Status": [
                "Active",
                "Inactive"
              ],
            },

          ]
        }}
        onSubmit={appContext?.onSubmit}
      />
    </div>
  )
}

export default User