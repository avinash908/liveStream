import { useContext, useState } from 'react'
import './login.css'
import { AppContext } from '../../context/AppContext';
function AdminLogin() {
    const [isLoading, setIsLoading] = useState(false);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [username, setUsername] = useState("");

    const appContext = useContext(AppContext);

    const onLogin = async () => {
        if (email == "" && password == "") {
            alert("Please Enter email and password");
        } else if (email == "") {
            alert("Please Enter email");
        }
        else if (!validateEmail(email)) {
            alert("Please Enter valid email");
        }
        else if (password == "") {
            alert("Please Enter email");
        } else {
            setIsLoading(true);
            await appContext?.adminLogin!({ email, password });
            setIsLoading(false);
        }
    }


    const validateEmail = (email: string) => {
        return String(email)
            .toLowerCase()
            .match(
                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
    };

    const onSingup = async () => {
        if (email == "" && password == "" && username == "") {
            alert("Please Enter username, email and password");
        } else if (username == "") {
            alert("Please Enter username");
        } else if (email == "") {
            alert("Please Enter email");
        }
        else if (!validateEmail(email)) {
            alert("Please Enter valid email");
        }
        else if (password == "") {
            alert("Please Enter email");
        } else {
            setIsLoading(true);
            await appContext?.adminRegister!({ email, password,username });
            setIsLoading(false);
        }
    }


    return (
        <div style={{
            width: window.innerWidth,
            height: window.innerHeight,
            background: "#0B1416",
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
        }}>
            <div className="container">
                <div id="cover">
                    <h1 className="sign-up">Welcome Back!</h1>
                    <p className="sign-up">
                        To keep connected with us please
                        <br />
                        login with your personal info
                    </p>
                    <a className="button sign-up" href="#cover">
                        Sign In
                    </a>
                    <h1 className="sign-in">Hello Friend!</h1>
                    <p className="sign-in">
                        Enter your Personal details
                        <br />
                        and start a journey with us
                    </p>
                    <br />
                    <a className="button sub sign-in" href="#">
                        Sign Up
                    </a>
                </div>
                <div className="login">
                    <h1>Sign In</h1>
                    <input type="email" placeholder="Email"
                        onChange={(e) => setEmail(e.target.value)}
                        className="input-field" />
                    <br />
                    <input type="password" onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="input-field" />
                    <br />
                    <a id="forgot-pass" href="#">
                        Forgot your password
                    </a>
                    <br />
                    <input type="submit" onClick={onLogin} value={isLoading ? "Please Wait..." : "Sign In"} className="submit-btn" />
                </div>
                <div className="register">
                    <h1>Create Account</h1>
                    <input type="text" onChange={(e) => setUsername(e.target.value)} placeholder="Username" className="input-field" />
                    <br />
                    <input type="email" onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="input-field" />
                    <br />
                    <input type="password" onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="input-field" />
                    <br />
                    <input className="submit-btn" onClick={onSingup} type="submit" value={isLoading ? "Please Wait..." : "Sign Up"}/>
                </div>
            </div>

        </div>
    )
}

export default AdminLogin