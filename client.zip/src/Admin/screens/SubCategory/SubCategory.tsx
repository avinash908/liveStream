import React, { useContext, useState } from 'react'
import { AppContext } from '../../../context/AppContext';
import { Box, Button, InputAdornment, TextField, Typography } from '@mui/material';
import { Search } from '@mui/icons-material';
import AlertDialogSlide from '../../Components/Modal/Modal';
import ReactVirtualizedTable from '../../Components/Table/Table';
import '../../style.css';

const columns: any = [
    {
        width: 200,
        label: 'id',
        dataKey: '_id',
    },
    {
        width: 120,
        label: 'Title',
        dataKey: 'title',
    },
    {
        width: 120,
        label: 'Description',
        dataKey: 'description',
    },
    {
        width: 120,
        label: 'Category',
        dataKey: 'category',
    },
    {
        width: 120,
        label: 'Status',
        dataKey: 'status',
    },
    {
        width: 120,
        label: 'Action',
        dataKey: 'action',
    },

];
function SubCategory() {
    const appContext = useContext(AppContext);
    const [open, setOpen] = useState(false);
    return (
        <div> <Box
            sx={{
                paddingTop: 5,
                paddingLeft: 5,
                display: "flex",
                alignItems: 'center',
                justifyContent: "space-between"
            }}
        >
            {/* <TextField
                id="input-with-icon-textfield"
                sx={{ visibility: "hidden" }}
                label="Search"
                InputLabelProps={{
                    classes: {
                        formControl: "lebal"
                    },
                    sx: {
                        visibility: "hidden"
                    }
                }}
                style={{ width: "40%", borderColor: "#fff" }}
                InputProps={{
                    startAdornment: (
                        <InputAdornment position="start">
                            <Search sx={{ color: "#ccc" }} />
                        </InputAdornment>
                    ),
                    classes: {
                        notchedOutline: "outlineStyle",
                    },
                    sx: {
                        color: "#fff"
                    }
                }}
                variant="outlined"
            /> */}
        <Typography fontSize={25} color={"white"} fontWeight={600} py={3}>Sub Category</Typography>

            <Button
                onClick={() => { setOpen(true) }}
                variant="outlined" sx={{
                    borderColor: "green",
                    marginX: 2,
                    color: "#fff",
                    outline: "none",
                    ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
                }} >
                Add New
            </Button>
        </Box>
            <Box sx={{
                paddingLeft: 5,
                paddingRight: 5,
                marginBlock: 10,
            }}>
                {appContext?.allFetchSubCategory == null ? <p>Please wait...</p> : <ReactVirtualizedTable
                    tableType={{ type: "SUBCATEGORY" }}
                    header={columns} data={appContext?.allFetchSubCategory} />}
            </Box>
            {appContext?.allFetchCategory == null ? null : <AlertDialogSlide
                title='Add Sub Category'
                onClose={() => { setOpen(false) }}
                open={open}
                fields={{
                    input: ["Title", 'description'],
                    dorpdown: [
                        {
                            "Category": appContext?.allFetchCategory?.map(v => ({ "value": v.title, "id": v._id }))
                        },
                        {
                            "Status": ['Active', "InActive"]
                        }
                    ]
                }}
                onSubmit={appContext?.onSubCategorySubmit}
            />}
        </div>
    )
}

export default SubCategory