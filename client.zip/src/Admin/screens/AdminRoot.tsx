import React from 'react'
import Header from '../Components/Header/Header'
import SideBar from '../Components/SideBar/SideBar'
import { Outlet } from 'react-router-dom'

function AdminRoot() {
  return (
    <div>
      <Header />
      <div style={{ display: 'flex', justifyContent: "space-between", background: "#0B1416", width: "100%", height: "92vh" }}>
        <div style={{
          width: "25%",
          borderRight: '0.5px solid #ffffff1a'
        }}>
          <SideBar />
        </div>
        <div style={{ width: "75%" }}>
          <Outlet />
        </div>
      </div>
    </div>
  )
}

export default AdminRoot