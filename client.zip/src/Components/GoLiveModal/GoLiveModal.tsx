import { TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Slide from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';
import * as React from 'react';
import './style.css';
import { AppContext } from '../../context/AppContext';
const Transition = React.forwardRef(function Transition(
    props: TransitionProps & {
        children: React.ReactElement<any, any>;
    },
    ref: React.Ref<unknown>,
) {
    return <Slide direction="down" ref={ref} {...props} />;
});



interface MoadlType {
    onShowModal?: () => void,
    open: boolean,
    onClose: () => void,
    title: string,
    onSubmit?: (data: any) => Promise<void>,
    isLoader?: boolean
}

export default function GoLiveModal({ open, onClose, title, onSubmit, isLoader }: MoadlType) {

    const [isCategory, setIsCategory] = React.useState(false);
    const [isState, setIsState] = React.useState(false);
    const [isCity, setIsCity] = React.useState(false);
    const [isAres, setIsAres] = React.useState(false);
    const [base64, setBase64] = React.useState<string | ArrayBuffer | null>("");

    async function getBase64(file: any) {
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
            console.log("done");
            setBase64(reader.result);
        };
        reader.onerror = function (error) {
            console.log('Error: ', error);
            setBase64("");

        };
    }

    const appContext = React.useContext(AppContext);
    return (
        <Dialog
            open={open}
            TransitionComponent={Transition}
            keepMounted
            onClose={onClose}
            aria-describedby="alert-dialog-slide-description"
        >
            <DialogTitle color={"white"}>{title}</DialogTitle>
            <form onSubmit={async (event) => {
                event.preventDefault();
                const data = new FormData(event.target as HTMLFormElement);
                var object: any = {
                    postTitle: "",
                    postOrigin: {
                        countryId: ""
                    },
                    postTopic: {
                        categoryId: '',
                    },
                    userId: appContext?.localUser._id,
                    status: true,
                    isLive: true
                };
                data.forEach(async function (value, key) {
                    if (key == "countryId" || key == "stateId" || key == "cityId" || key == "areaId") {
                        if (key == "stateId" && value == "Select State") {
 
                        } else {
                            object.postOrigin[key] = value;
                        }
                    } else if (key == "categoryId" || key == "subCategoryId") {
                        if (key == "subCategoryId" && value == "Select Sub Topic") {
 
                        } else {
                            object.postTopic[key] = value;
                        }
                    } else if (key == "postThumbnail") {
                        console.log(value);
                        object[key] = base64
                    } else {
                        object[key] = value;
                    }
                });
                console.log(object);
                await onSubmit!(object);
            }}>
                <DialogContent>
                    <TextField
                        name={"postTitle"}
                        placeholder={`Enter Post Title`} sx={{
                            width: "100%"
                        }}
                        InputProps={{
                            sx: {
                                color: "#fff",
                                outlineColor: "green",
                                marginBlock: 1
                            },
                            style: {
                                color: "#fff",
                                outlineColor: "green"
                            },
                            classes: {
                                notchedOutline: "outlineStyle",
                            },
                        }}
                    />
                    <select name={"countryId"}
                        onChange={(e) => {
                            if (e.target.value != "Select Country") {
                                setIsState(true);
                            } else {
                                setIsState(false);

                            }
                        }}
                        style={{
                            width: "100%",
                            height: 50,
                            outline: 'none',
                            background: "transparent",
                            borderColor: "#cccccc35",
                            borderRadius: 4,
                            marginBlock: 6,
                            color: "#777",
                            paddingLeft: 10,
                        }}>
                        <option selected>
                            Select Country
                        </option>
                        {
                            appContext?.allFetchCountries && appContext.allFetchCountries.map((v, k) => {
                                return <option value={v._id} key={k}>
                                    {v.country}
                                </option>
                            })
                        }
                    </select>
                    {
                        isState && <select name={"stateId"}
                            onChange={(e) => {
                                if (e.target.value != "Select State") {
                                    setIsCity(true);
                                } else {
                                    setIsCity(false);

                                }
                            }}
                            style={{
                                width: "100%",
                                height: 50,
                                outline: 'none',
                                background: "transparent",
                                borderColor: "#cccccc35",
                                borderRadius: 4,
                                marginBlock: 6,
                                color: "#777",
                                paddingLeft: 10,
                            }}>
                            <option selected>
                                Select State
                            </option>
                            {
                                appContext?.allFetchStates && appContext.allFetchStates.map((v, k) => {
                                    return <option value={v._id} key={k}>
                                        {v.state}
                                    </option>
                                })
                            }
                        </select>
                    }
                    {
                        isCity && <select name={"cityId"}
                            onChange={(e) => {
                                if (e.target.value != "Select City") {
                                    setIsAres(true);
                                } else {
                                    setIsAres(false);

                                }
                            }}
                            style={{
                                width: "100%",
                                height: 50,
                                outline: 'none',
                                background: "transparent",
                                borderColor: "#cccccc35",
                                borderRadius: 4,
                                marginBlock: 6,
                                color: "#777",
                                paddingLeft: 10,
                            }}>
                            <option selected>
                                Select City
                            </option>
                            {
                                appContext?.allFetchCites && appContext.allFetchCites.map((v, k) => {
                                    return <option value={v._id} key={k}>
                                        {v.city}
                                    </option>
                                })
                            }
                        </select>
                    }
                    {
                        isAres && <select name={"areaId"}

                            style={{
                                width: "100%",
                                height: 50,
                                outline: 'none',
                                background: "transparent",
                                borderColor: "#cccccc35",
                                borderRadius: 4,
                                marginBlock: 6,
                                color: "#777",
                                paddingLeft: 10,
                            }}>
                            <option selected>
                                Select Area
                            </option>
                            {
                                appContext?.allFetchArea && appContext.allFetchArea.map((v, k) => {
                                    return <option value={v._id} key={k}>
                                        {v.area}
                                    </option>
                                })
                            }
                        </select>
                    }
                    <select name={"categoryId"}
                        onChange={(e) => {
                            if (e.target.value != "Select Topic") {
                                setIsCategory(true);
                            } else {
                                setIsCategory(false);
                            }
                        }}
                        style={{
                            width: "100%",
                            height: 50,
                            outline: 'none',
                            background: "transparent",
                            borderColor: "#cccccc35",
                            borderRadius: 4,
                            marginBlock: 6,
                            color: "#777",
                            paddingLeft: 10,
                        }}>
                        <option selected>
                            Select Topic
                        </option>
                        {
                            appContext?.allFetchCategory && appContext.allFetchCategory.map((v, k) => {
                                return <option value={v._id} key={k}>
                                    {v.title}
                                </option>
                            })
                        }
                    </select>
                    {
                        isCategory && <select name={"subCategoryId"}

                            style={{
                                width: "100%",
                                height: 50,
                                outline: 'none',
                                background: "transparent",
                                borderColor: "#cccccc35",
                                borderRadius: 4,
                                marginBlock: 6,
                                color: "#777",
                                paddingLeft: 10,
                            }}>
                            <option selected>
                                Select Sub Topic
                            </option>
                            {
                                appContext?.allFetchSubCategory && appContext.allFetchSubCategory.map((v, k) => {
                                    return <option value={v._id} key={k}>
                                        {v.title}
                                    </option>
                                })
                            }
                        </select>


                    }
                    <TextField
                        helperText="Post Thumbnail (optional)"
                        name={"postThumbnail"}
                        placeholder={`Upload Post Thumbnail`} sx={{
                            width: "100%"
                        }}
                        onChange={async (e: any) => {
                            console.log(e.target.files)
                            if (e.target.files) {
                                await getBase64(e.target.files[0])
                            }
                        }}
                        type='file'
                        FormHelperTextProps={{
                            sx: {
                                color: "#fff"
                            }
                        }}
                        InputProps={{
                            sx: {
                                color: "#fff",
                                outlineColor: "green",
                                marginBlock: 1,
                                marginTop: 1

                            },
                            style: {
                                color: "#fff",
                                outlineColor: "green",

                            },
                            classes: {
                                notchedOutline: "outlineStyle",
                            },
                        }}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={onClose}
                        variant="contained" sx={{
                            borderColor: "green",
                            marginX: 2,
                            color: "#111",
                            outline: "none",
                            backgroundColor: "#ccc",
                            ":hover": { background: "#777", borderColor: "#777", color: "#fff" }
                        }}
                    >Close</Button>
                    <Button type="submit" variant="outlined" sx={{
                        borderColor: "green",
                        marginX: 2,
                        color: "#fff",
                        outline: "none",
                        ":hover": { background: "#fff", borderColor: "#fff", color: "green" }
                    }} >{isLoader ? "Please Wait..." : "Submit"}</Button>
                </DialogActions>
            </form>
        </Dialog>
    );
}