import HomeIcon from '../../Assets/Svg/home.svg';
import PopularIcon from '../../Assets/Svg/popular.svg';
import Game from '../../Assets/Svg/game.svg';
import Sport from '../../Assets/Svg/sport.svg';
import Business from '../../Assets/Svg/business.svg';
import Crypto from '../../Assets/Svg/crypto.svg';
import Television from '../../Assets/Svg/television.svg';
import Celebrity from '../../Assets/Svg/celebrity.svg';


import { ArrowForwardIos, Category, Flag } from '@mui/icons-material';
import "./style.css";
import { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { CityType, CountryType, StateType } from '../../context/@Types/AppContextType';


interface SubmenuType {
  title: string,
  href?: string,
}

interface MenuType {
  title: string,
  icon?: any,
  href?: string,
  submenu?: Array<SubmenuType>
}

const menus: Array<MenuType> = [
  {
    title: "Home",
    icon: HomeIcon
  },
  {
    title: "Popular",
    icon: PopularIcon
  },
];

const moreMenus: Array<MenuType> = [
  {
    title: "Animals and Pets",
  },
  {
    title: "Anime",
  },
  {
    title: "Art",
  },
  {
    title: "Cars and Motor Vehicles",
  },
  {
    title: "Craft and DIY",
  },
  {
    title: "Culture, Race, and Ethnicity",
  },
  {
    title: "Ethics and Philosophy",
  },
  {
    title: "Fashion",
  },
  {
    title: "Food and Drink",
  },
  {
    title: "History",
  },
  {
    title: "Hobbies",
  },
  {
    title: "Law",
  },
  {
    title: "Learning and Education",
  },
  {
    title: "Military",
  },
  {
    title: "Movies",
  },
  {
    title: "Music",
  },
  {
    title: "Place",
  },
  {
    title: "Podcasts and Streamers",
  },
  {
    title: "Politics",
  },
  {
    title: "Programming",
  },
  {
    title: "Reading, Writing, and Literature",
  },
  {
    title: "Religion and Spirituality",
  },
  {
    title: "Science",
  },
  {
    title: "Tabletop Games",
  },
  {
    title: "Technology",
  },
  {
    title: "Travel",
  },
];


const dropdownMenu: Array<MenuType> = [
  {
    title: "Gaming",
    icon: Game,
    submenu: [
      {
        title: "Valheim",
        href: "",
      },
      {
        title: "Genshin Impact",
        href: "",
      },
      {
        title: "Minecraft",
        href: "",
      },
      {
        title: "Pokimane",
        href: "",
      },
      {
        title: "Halo Infinite",
        href: "",
      },

      {
        title: "Call of Duty: Warzone",
        href: "",
      },
      {
        title: "Path of Exile",
        href: "",
      },
      {
        title: "Hollow Knight: Silksong",
        href: "",
      },
      {
        title: "Escape from Tarkow",
        href: "",
      },
      {
        title: "Watch Dogs: Legion",
        href: "",
      }
    ]
  },
  {
    title: "Sport",
    icon: Sport,
    submenu: [
      {
        title: "NFL",
        href: "",
      },
      {
        title: "NBA",
        href: "",
      },
      {
        title: "Megan Anderson",
        href: "",
      },
      {
        title: "Atlanta Hawks",
        href: "",
      },
      {
        title: "Los Angeles Lakers",
        href: "",
      },

      {
        title: "Boston Celtics",
        href: "",
      },
      {
        title: "Arsenal F.C.",
        href: "",
      },
      {
        title: "Philadelphia 76ers",
        href: "",
      },
      {
        title: "Premier League",
        href: "",
      },
      {
        title: "UFC",
        href: "",
      }
    ]
  },
  {
    title: "Business",
    icon: Business,
    submenu: [
      {
        title: "GameStop",
        href: "",
      },
      {
        title: "Moderna",
        href: "",
      },
      {
        title: "Pfizer",
        href: "",
      },
      {
        title: "Johnson & Johnson",
        href: "",
      },
      {
        title: "AstraZeneca",
        href: "",
      },

      {
        title: "Walgreens",
        href: "",
      },
      {
        title: "Best Buy",
        href: "",
      },
      {
        title: "Novavax",
        href: "",
      },
      {
        title: "Spacex",
        href: "",
      },
      {
        title: "Tesla",
        href: "",
      }
    ]
  },
  {
    title: "Crypto",
    icon: Crypto,
    submenu: [
      {
        title: "Cardano",
        href: "",
      },
      {
        title: "Dogecoin",
        href: "",
      },
      {
        title: "Algorand",
        href: "",
      },
      {
        title: "Bitcoin",
        href: "",
      },
      {
        title: "Litecoin",
        href: "",
      },

      {
        title: "Basic Attention Token",
        href: "",
      },
      {
        title: "Bitcoin Cash",
        href: "",
      },
    ]
  },
  {
    title: "Television",
    icon: Television,
    submenu: [
      {
        title: "The Real Housewives of Atlanta",
        href: "",
      },
      {
        title: "The Bachelor",
        href: "",
      },
      {
        title: "Sister Wives",
        href: "",
      },
      {
        title: "90 Day Fiance",
        href: "",
      },
      {
        title: "Wife Swap",
        href: "",
      },

      {
        title: "The Amazing Race Australia",
        href: "",
      },
      {
        title: "Married at First Sight",
        href: "",
      },
      {
        title: "The Real Housewives of Dallas",
        href: "",
      },
      {
        title: "My 600-lb Life",
        href: "",
      },
      {
        title: "Last Week Tonight with John Oliver",
        href: "",
      },
    ]
  },
  {
    title: "Celebrity",
    icon: Celebrity,
    submenu: [
      {
        title: "Kim  Kardashian",
        href: "",
      },
      {
        title: "Doja Cat",
        href: "",
      },
      {
        title: "lggy Azalea",
        href: "",
      },
      {
        title: "Anya Taylor-joy",
        href: "",
      },
      {
        title: "Jamie Lee Curtis",
        href: "",
      },

      {
        title: "Natalie Portman",
        href: "",
      },
      {
        title: "Henry Cavill",
        href: "",
      },
      {
        title: "Millie Bobby Brown",
        href: "",
      },
      {
        title: "Tom Hiddleston",
        href: "",
      },
      {
        title: "Keanu Reeves",
        href: "",
      },
    ]
  },
];


const SideBar = () => {
  const appContext = useContext(AppContext);

  const onMenuClick = (menuType: "menu" | "dropdown", id: string) => {
    if (menuType === "dropdown") {
      if (document.getElementById(id)?.style.getPropertyValue("display") === "block") {
        document.getElementById(id)!.style.display = "none";
      } else {
        document.getElementById(id)!.style.display = "block";
      }
    }
  }

  const onMoreClick = (event: any) => {
    if (document.getElementById("moreMenu")?.style.getPropertyValue('display') === 'block') {
      event.target.innerText = "Show More";
      document.getElementById("moreMenu")!.style.display = 'none';
    } else {
      event.target.innerText = "Show Less";
      document.getElementById("moreMenu")!.style.display = 'block';
    }
  }



  return (
    <div className="sideBar" id='sideBar'>
      <div className='menu'>
        {
          menus.map((v, i) => {
            return <div key={i}>
              <img src={v.icon} alt='icon' />
              <span>{v.title}</span>
            </div>
          })
        }
      </div>
      <div className='divider'></div>
      <div className='headingBox'>
        <p>PLACSES</p>
      </div>
      <div className='dropdownMenu menu'>
        {
          appContext?.allFetchCountries?.map((v, i) => {
            const state = v.state;
            return <div className='menuBox' key={i}>
              <div onClick={() => { state?.length! > 0 ? onMenuClick("dropdown", `menuOpen${i}`) : console.log("Not") }} className='menuItem'>
                <Flag />
                <span>{v.country}</span>
                {state?.length! > 0 ? <ArrowForwardIos className='arrowIcon' /> : null}
              </div>
              <div className='dropDownDiv' style={{ width: "100%", marginLeft: 0 }} id={`menuOpen${i}`}>
                {
                  state?.map((menu: StateType, index: number) => {
                    const cites = menu.city;
                    return <div className='dropdownMenu menu' style={{ width: '100%' }} key={index}>
                      <div onClick={() => { cites?.length! > 0 ? onMenuClick("dropdown", `menuOpen${menu._id}`) : console.log("Not") }} className='menuItem'>
                        <Flag />
                        <span>{menu.state}</span>
                        {cites?.length! > 0 ? <ArrowForwardIos className='arrowIcon' /> : null}
                      </div>
                      <div className='dropDownDiv' id={`menuOpen${menu._id}`}>
                        {
                          cites?.map((city: CityType, ci) => {
                            const areas = city.area;
                            return <div className='dropdownMenu menu' style={{ width: '100%', paddingLeft: 0, paddingRight: 0, }} key={index}>
                              <div onClick={() => { areas?.length! > 0 ? onMenuClick("dropdown", `menuOpen${city._id}`) : console.log("Not") }}
                                style={{ width: '100%', paddingLeft: 0, paddingRight: 0 }}
                                className='menuItem'>
                                <Flag />
                                <span>{city.city}</span>
                                {areas?.length! > 0 ? <ArrowForwardIos className='arrowIcon' /> : null}
                              </div>
                              <div className='dropDownDiv' id={`menuOpen${city._id}`}>
                                {
                                  areas?.map((area, ai) => {
                                    return <p key={area._id}>{area.area}</p>
                                  })
                                }
                              </div>
                            </div>
                          })
                        }
                      </div>
                    </div>
                  })
                }
              </div>
            </div>
          })
        }
      </div>
      {/* {appContext?.menuCountry == null ? <p></p> : <div className='dropdownMenu menu'>
        {
          Object.keys(appContext?.menuCountry).map((v: string, k) => {
            const subMenu = appContext?.menuCountry == null ? null : appContext?.menuCountry[v];
            return <div className='menuBox' key={k}>
              <div onClick={() => { onMenuClick("dropdown", `menuOpen${k}`) }} className='menuItem'>
                <Flag />
                <span>{v}</span>
                <ArrowForwardIos className='arrowIcon' />
              </div>
              <div className='dropDownDiv' id={`menuOpen${k}`}>
                {
                  subMenu?.map((menu: any, index: number) => {
                    return <p key={index}>{menu}</p>
                  })
                }
              </div>
            </div>
          })
        }
      </div>} */}

      {/* <div className='dropdownMenu menu'>
        {
          dropdownMenu.map((v, i) => {
            return <div className='menuBox' key={i}>
              <div onClick={() => { onMenuClick("dropdown", `menuOpen${i}`) }} className='menuItem'>
                <img src={v.icon} alt='icon' />
                <span>{v.title}</span>
                <ArrowForwardIos className='arrowIcon' />
              </div>
              <div className='dropDownDiv' id={`menuOpen${i}`}>
                {
                  v.submenu?.map((menu, index) => {
                    return <p key={index}>{menu.title}</p>
                  })
                }
              </div>
            </div>
          })
        }
      </div>
      <div className='moreMenus' id='moreMenu' >
        {
          moreMenus?.map((menu, index) => {
            return <p key={index}>{menu.title}</p>
          })
        }
      </div>
      <div className='showMore' onClick={onMoreClick}>
        <p>Show More</p>
      </div> */}
      <div className='divider'></div>
      <div className='headingBox'>
        <p>Topics</p>
      </div>
      {appContext?.menuTopics == null ? <p></p> : <div className='dropdownMenu menu'>
        {
          appContext?.menuTopics.map((v: any, k) => {
            return <div className='menuBox' key={k}>
              <div onClick={() => { v.subcategory?.length > 0 ? onMenuClick("dropdown", `menuOpen${v._id}`) : console.log("dd") }} className='menuItem'>
                <Category />
                <span>{v.title}</span>
                <ArrowForwardIos className='arrowIcon' />
              </div>
              {
                v.subcategory?.length > 0 ?
                  <div className='dropDownDiv' id={`menuOpen${v._id}`}>
                    {
                      v.subcategory?.map((menu: any, index: number) => {
                        return <p key={index}>{menu.title}</p>
                      })
                    }
                  </div>
                  : null
              }

            </div>
          })
        }
      </div>}

    </div>
  )
}


export default SideBar;