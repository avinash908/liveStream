import LoginModal from "react-login-modal-sm";
import { onHttpPostRequset } from "../../Api/base_api";
import { AxiosError } from "axios";
import { useContext } from "react";
import { AppContext } from "../../context/AppContext";


interface LoginModalType {
    showModal: boolean,
    closeModal: () => void,
}

const CustomLoginModal = (props: LoginModalType) => {
    const appContext = useContext(AppContext);
    return <LoginModal showModal={props.showModal}
        toggleModal={props.closeModal}
        orLabel="OR"
        onLoginEmail={async (email: string, password: string) => {
            var isSuccess = await appContext?.onLoginEmail!(email, password);
            if (isSuccess) {
                props.closeModal();
            }
        }}
        onSignupEmail={async (email: string, username: string, password: string) => {
            var isSuccess = await appContext?.onSignupEmail!(email, username, password);
            if (isSuccess) {
                props.closeModal();
            }
        }}
    />
}


export default CustomLoginModal;