import { Menu, MoreHoriz, Search } from '@mui/icons-material';
import { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import LoginModal from '../LoginModal/CustomLoginModal';
import './style.css';
import { Link } from 'react-router-dom';
import Logo from '../../Assets/Images/logo-removebg-preview.png';
interface HederType {
    menuClick: () => void,
}
export const Header = ({ menuClick }: HederType) => {
    const [showModal, setShowModal] = useState(false);
    const appContext = useContext(AppContext);
    const onShowModal = () => {
        setShowModal(true);
    }
    return (
        <div className='header'>
            <div className='logoDiv'>
                <Menu className='menuBtn' onClick={menuClick} />
                <img src={Logo}/>
                {/* <p>Your Logo</p> */}
            </div>
            <div className='inputBox'>
                <Search className='icond' />
                <input placeholder='Search here...' />
            </div>
            <div className='actionBox'>
                <button >
                    {/* <QrCode2Rounded /> */}
                    <span>Insert Topics</span>
                </button>
                {appContext?.localUser == null ? <button onClick={onShowModal}>Login</button> : <button onClick={appContext.onLogout}>Logout</button>}
                <button><MoreHoriz />
                    {appContext?.localUser?.userType == "Admin" ? <ul className='submenu'>
                        {/* <li><Link to={"#"}>Setting</Link></li> */}
                        <li><Link to={"/admin/dashboard"} style={{ color: "#fff", textDecoration: "none" }}> Admin Area</Link></li>
                    </ul> : null}
                </button>
            </div>
            <LoginModal showModal={showModal} closeModal={() => setShowModal(false)} />
        </div>
    )
}
export default (Header)

