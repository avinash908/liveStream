import axios, { AxiosError, AxiosResponse } from 'axios';


export interface HttpPostType {
    data: any,
    path: string,
    onSuccess: (response: AxiosResponse) => void,
    onError: (error: AxiosError | unknown) => void,
}

export interface HttpGetType {
    path: string,
    onSuccess: (response: AxiosResponse) => void,
    onError: (error: AxiosError | unknown) => void,
    qurery?: string
}

export const URL = "https://3.85.47.74:4100/api/v1";

const baseAxios = axios.create({
    baseURL: URL,
})

export const onHttpPostRequset = async ({ data, path, onSuccess, onError }: HttpPostType) => {
    try {
        const response = await baseAxios.post(path, data);
        return onSuccess(response);
    } catch (error) {
        return onError(error);
    }
}


export const onHttpGetRequset = async ({ path, onError, onSuccess, qurery }: HttpGetType) => {
    try {
        const response = await baseAxios.get(path, {
            params: qurery
        });
        return onSuccess(response);
    } catch (error) {
        return onError(error);
    }
}