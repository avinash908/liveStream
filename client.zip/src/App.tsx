import './App.css';

import {
  createBrowserRouter,
  RouterProvider
} from "react-router-dom";
import Root from './Root';
import HomeScreen from './Screens/Home/HomeScreen';
import { AppContextProvider } from './context/AppContext';
import Index from './Admin/Index';
import AdminLogin from './Admin/screens/AdminLogin';
import AdminRoot from './Admin/screens/AdminRoot';
import DashBoard from './Admin/screens/DashBoard/DashBoard';
import User from './Admin/screens/User/User';
import Country from './Admin/screens/Country/Country';
import Category from './Admin/screens/Category/Category';
import SubCategory from './Admin/screens/SubCategory/SubCategory';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';

const router = createBrowserRouter(
  [
    {
      path: '/',
      element: <Root />,
      children: [
        {
          path: '/',
          element: <HomeScreen />
        }
      ]
    },
    {
      path: "/admin",
      element: <Index />,
    },
    {
      path: "/admin/login",
      element: <AdminLogin />
    },
    {
      path: "/admin/dashboard",
      element: <AdminRoot />,
      children: [
        {
          path: "/admin/dashboard",
          element: <DashBoard />
        },
        {
          path: "/admin/dashboard/users",
          element: <User />
        },
        {
          path: "/admin/dashboard/country",
          element: <Country />
        },
        {
          path: "/admin/dashboard/category",
          element: <Category />
        },
        {
          path: "/admin/dashboard/sub-category",
          element: <SubCategory />
        }
      ]
    }
  ]
);




function App() {
  return (
    <AppContextProvider>
      <RouterProvider router={router} />
      <ToastContainer/>
    </AppContextProvider>
  );
}

export default App;
