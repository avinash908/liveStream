import ReactDOM from 'react-dom/client';
import App from './App';
import { LiveStreamContextProvider } from './LiveSdk/Context/LiveStreamContext';
import './index.css';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <LiveStreamContextProvider>
    <App />
  </LiveStreamContextProvider>
);
