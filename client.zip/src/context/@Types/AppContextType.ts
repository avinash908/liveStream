import React, { FormEventHandler } from "react"



interface LoginType {
    email: string,
    password: string,
    username?: string
}


export interface UserType {
    _id: string
    username: string
    email: string
    token?: string
    address?: Address
    follower?: string[]
    following?: string[]
    status: boolean
    createdAt: any
    updatedAt: any
    __v: any,
    userType: string
}


export interface Address {
    city?: string
    state?: string
    zipCode?: string
    subDivision?: string
    country?: string
}



export interface CountryType {
    _id?: string
    country: string,
    state?: Array<StateType>
    createdAt?: any
    updatedAt?: any
    __v?: any,
    status?: boolean
}


export interface StateType {
    _id?: string
    countryId: string,
    state: string,
    city?: Array<CityType>
    createdAt?: any
    updatedAt?: any
    __v?: any,
    status?: boolean
}


export interface CityType {
    _id?: string
    countryId: string,
    stateId: string,
    city: string,
    area?: Array<AreaType>,
    createdAt?: any
    updatedAt?: any
    __v?: any,
    status?: boolean
}


export interface AreaType {
    _id?: string
    countryId: string,
    stateId: string,
    cityId: string,
    area: string,
    createdAt?: any
    updatedAt?: any
    __v?: any,
    status?: boolean
}

export interface Coordinates {
    lat: number
    lng: number
}

//   export interface CreatedAt {
//     $date: Date
//   }

//   export interface Date {
//     $numberLong: string
//   }

//   export interface UpdatedAt {
//     $date: Date2
//   }

//   export interface Date2 {
//     $numberLong: string
//   }

//   export interface V {
//     $numberInt: string
//   }



export interface CraetedPostType {
    isSuccess: boolean,
    roomId: string | null,
}


export interface AppContextType {
    onLoginEmail?: (email: string, password: string) => Promise<boolean>,
    onSignupEmail?: (email: string, username: string, password: string) => Promise<boolean>,
    localUser?: any | null,
    setLocalUser?: React.Dispatch<any | null>,
    onLogout?: () => void,
    adminLogin?: ({ email, password }: LoginType) => Promise<void>,
    adminRegister?: ({ email, password, username }: LoginType) => Promise<void>,
    onFetchUser?: () => Promise<void>,
    allFetchUsers?: Array<UserType> | null,
    countryId?: string | null,
    setCountryId?: React.Dispatch<React.SetStateAction<string | null>>,
    stateId?: string | null,
    setStateId?: React.Dispatch<React.SetStateAction<string | null>>,
    setAllFetchUsers?: React.Dispatch<React.SetStateAction<UserType[] | null>>,
    onFetchCountry?: () => Promise<void>,
    allFetchCountries?: Array<CountryType> | null,
    setAllFetchCountries?: React.Dispatch<React.SetStateAction<CountryType[] | null>>,
    allFetchStates?: Array<StateType> | null,
    setAllFetchStates?: React.Dispatch<React.SetStateAction<StateType[] | null>>,
    allFetchCites?: Array<CityType> | null,
    setAllFetchCites?: React.Dispatch<React.SetStateAction<CityType[] | null>>,
    allFetchArea?: Array<AreaType> | null,
    setAllFetchArea?: React.Dispatch<React.SetStateAction<AreaType[] | null>>,
    onSubmit?: (data: any) => Promise<boolean>,
    onCountrySubmit?: (data: any) => Promise<boolean>,
    onStateSubmit?: (data: any) => Promise<boolean>,
    onCitySubmit?: (data: any) => Promise<boolean>,
    onAreaSubmit?: (data: any) => Promise<boolean>,
    onCategorySubmit?: (data: any) => Promise<boolean>,
    allFetchCategory?: Array<any> | null,
    setAllFetchCategory?: React.Dispatch<React.SetStateAction<any[] | null>>,
    onSubCategorySubmit?: (data: any) => Promise<boolean>,
    allFetchSubCategory?: Array<any> | null,
    setAllFetchSubCategory?: React.Dispatch<React.SetStateAction<any[] | null>>,
    menuCountry?: any | null,
    setMenuCountry?: React.Dispatch<React.SetStateAction<{} | null>>,
    menuTopics?: Array<any> | null,
    setMenuTopics?: React.Dispatch<React.SetStateAction<Array<any> | null>>,
    customToast: (message: string) => void,
    onCreatePost?: (data: any) => Promise<CraetedPostType>,
    allPosts?: Array<any> | null,
    setAllPosts?: React.Dispatch<React.SetStateAction<Array<any> | null>>,
}

