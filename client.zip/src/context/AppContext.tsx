import { AxiosError } from "axios";
import { createContext, useEffect, useState } from "react";
import { onHttpGetRequset, onHttpPostRequset } from "../Api/base_api";
import { AppContextType, AreaType, CityType, CountryType, CraetedPostType, StateType, UserType } from "./@Types/AppContextType";
import { toast } from 'react-toastify';

const AppContext = createContext<AppContextType | null>(null);
const AppContextProvider = ({ children }: any) => {
    const [localUser, setLocalUser] = useState<any | null>(null);
    const [allFetchUsers, setAllFetchUsers] = useState<Array<UserType> | null>(null);
    const [allFetchCountries, setAllFetchCountries] = useState<Array<CountryType> | null>(null);
    const [allFetchStates, setAllFetchStates] = useState<Array<StateType> | null>(null);
    const [allFetchCites, setAllFetchCites] = useState<Array<CityType> | null>(null);
    const [allFetchArea, setAllFetchArea] = useState<Array<AreaType> | null>(null);
    const [countryId, setCountryId] = useState<string | null>(null);
    const [stateId, setStateId] = useState<string | null>(null);
    const [allFetchCategory, setAllFetchCategory] = useState<Array<any> | null>(null);
    const [allFetchSubCategory, setAllFetchSubCategory] = useState<Array<any> | null>(null);
    const [menuCountry, setMenuCountry] = useState<{} | null>(null);
    const [menuTopics, setMenuTopics] = useState<Array<any> | null>(null);
    const [allPosts, setAllPosts] = useState<Array<any> | null>(null);





    useEffect(() => {
        console.log("App is Started... Success");
        onGetLocalUser();
        onFetchUser();
        onFetchPosts();
        onFetchCountry();
        onFetchState();
        onFetchCity();
        onFetchArea();
        onFetchTopics();
        onFetchCategory();
        onFetchSubCategory();
    }, [])
    const onGetLocalUser = async () => {
        var user = window.localStorage.getItem("@authUser");
        if (user != null) {
            var newUser = JSON.parse(user);
            setLocalUser(newUser);

        }
    }


    const onLogout = () => {
        window.localStorage.clear();
        onGetLocalUser();
        window.location.reload();
    }

    const onLoginEmail = async (email: string, password: string) => {
        var isSuccess: boolean = false;
        await onHttpPostRequset(
            {
                path: "/users/login-user",
                data: { email, password },
                onSuccess: (response) => {
                    console.log(response.data);
                    if (response.status == 200) {
                        const user = JSON.stringify(response.data.data);
                        window.localStorage.setItem("@authUser", user);
                        onGetLocalUser();
                    }
                    isSuccess = true;
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                    isSuccess = false;
                }
            }
        );
        return isSuccess;
    }

    const onSignupEmail = async (email: string, username: string, password: string) => {
        var isSuccess: boolean = false;

        await onHttpPostRequset(
            {
                path: "/users/create-user",
                data: { email, password, username, userType: "User" },
                onSuccess: (response) => {
                    console.log(response.data);
                    if (response.status == 200) {
                        const user = JSON.stringify(response.data.data);
                        window.localStorage.setItem("@authUser", user);
                        onGetLocalUser();
                    }
                    isSuccess = true;
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                    isSuccess = false;

                }
            }
        );
        return isSuccess;
    }



    const adminLogin = async ({ email, password }: any) => {
        await onHttpPostRequset(
            {
                path: "/users/login-user",
                data: { email, password },
                onSuccess: (response) => {
                    if (response.status == 200) {
                        const user = JSON.stringify(response.data.data);
                        window.localStorage.setItem("@authUser", user);
                        onGetLocalUser();
                        window.location.replace("/");
                    }
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                }
            }
        );
    }

    const adminRegister = async ({ email, password, username }: any) => {
        await onHttpPostRequset(
            {
                path: "/users/create-user",
                data: { email, password, username, userType: "Admin" },
                onSuccess: (response) => {
                    console.log(response.data);
                    if (response.status == 200) {
                        const user = JSON.stringify(response.data.data);
                        window.localStorage.setItem("@authUser", user);
                        onGetLocalUser();
                        window.location.replace("/");
                    }
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                }
            }
        );
    }



    const onFetchUser = async () => {
        await onHttpGetRequset({
            path: "/users/",
            onSuccess: (response) => {
                if (response.status == 200) {
                    setAllFetchUsers(response.data.data);
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }

    const onFetchCountry = async () => {
        await onHttpGetRequset({
            path: "/countries/",
            onSuccess: (response) => {
                console.log(response.data);
                if (response.status == 200) {
                    setAllFetchCountries(response.data.data);
                }
                // response.data.data?.forEach((v: any) => {
                //     if (menu[v.country] != undefined) {
                //         var arr = menu[v.country] as Array<string>;
                //         arr?.push(v.city);
                //         menu[v.country] = arr!;
                //     } else {
                //         menu[v.country] = [v.city];
                //     }
                // });
                // setMenuCountry(menu);
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }

    const onFetchState = async () => {
        await onHttpGetRequset({
            path: "/countries/states",
            onSuccess: (response) => {
                console.log(response.data);
                if (response.status == 200) {
                    setAllFetchStates(response.data.data);
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }

    const onFetchCity = async () => {
        await onHttpGetRequset({
            path: "/countries/cites",
            onSuccess: (response) => {
                if (response.status == 200) {
                    setAllFetchCites(response.data.data);
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }
    const onFetchArea = async () => {
        await onHttpGetRequset({
            path: "/countries/area",
            onSuccess: (response) => {
                if (response.status == 200) {
                    setAllFetchArea(response.data.data);
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }

    const onFetchCategory = async () => {
        await onHttpGetRequset({
            path: "/category/",
            onSuccess: (response) => {
                if (response.status == 200) {
                    setAllFetchCategory(response.data.data);
                }

            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }
    const onFetchSubCategory = async () => {
        await onHttpGetRequset({
            path: "/category/sub-categroy",
            onSuccess: (response) => {
                if (response.status == 200) {
                    setAllFetchSubCategory(response.data.data);
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }
    const onFetchTopics = async () => {
        await onHttpGetRequset({
            path: "/category/menuTopics",
            onSuccess: (response) => {
                setMenuTopics(response.data.data);
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }


    const onFetchPosts = async () => {
        await onHttpGetRequset({
            path: "/post/",
            onSuccess: (response) => {
                if (response.status == 200) {
                    if (response.data.status) {
                        setAllPosts(response.data.data);
                    } else {
                        setAllPosts([]);
                    }
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
            }
        });
    }





    const validateEmail = (email: string) => {
        return email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    };

    const onSubmit = async (data: any) => {
        if (data instanceof Object) {
            const jsonDate = data as UserType;
            if (jsonDate.username == "" && jsonDate.email == "" && data.password == "") {
                customToast("Please fill all required fields username,email,password,user type and status")
                return false;
            } else if (jsonDate.username == "") {
                customToast("Please Enter username")
                return false;
            } else if (jsonDate.email == "") {
                customToast("Please Enter email")
                return false;
            } else if (!validateEmail(jsonDate.email)) {
                customToast("Please Enter valid email");
                return false;
            } else if (data.password == "") {
                customToast("Please Enter password");
                return false;
            } else if (jsonDate.userType == "Select User Type") {
                customToast("Please Select user type")
                return false;
            } else if (data.status == "Select Status") {
                customToast("Please Select Status")
                return false;
            } else {
                await onHttpPostRequset(
                    {
                        path: "/users/create-user",
                        data: { email: jsonDate.email, password: data.password, username: jsonDate.username, userType: jsonDate.userType },
                        onSuccess: (response) => {
                            if (response.status == 200) {
                                onFetchUser();
                                return true;
                            }
                        },
                        onError: (error) => {
                            if (error instanceof AxiosError) {
                                if (error.response != null) {
                                    customToast(error.response.data.message);
                                } else {
                                    customToast(error.message);
                                }
                            }
                            return false;
                        }
                    }
                );
            }

        }
        return false;
    }

    const onCountrySubmit = async (data: any) => {
        if (data instanceof Object) {
            const jsonDate = data as CountryType;
            if (jsonDate.country == "") {
                customToast("Please enter country name")
                return false;
            } else if (data.status == "Select Status") {
                customToast("Please Select Status");
                return false;
            } else {
                const countryObject: CountryType = {
                    country: jsonDate.country,
                    status: data.status == "Active" ? true : false

                }
                console.log(countryObject);
                await onHttpPostRequset({
                    path: "/countries/create",
                    data: countryObject,
                    onSuccess: (response) => {
                        if (response.status == 200) {
                            onFetchCountry();
                            return true;
                        }
                    },
                    onError: (error) => {
                        if (error instanceof AxiosError) {
                            if (error.response != null) {
                                customToast(error.response.data.message);
                            } else {
                                customToast(error.message);
                            }
                        }
                        return false;
                    }
                })
                return true;
            }
        }
        return false;
    }
    const onStateSubmit = async (data: any) => {
        if (data instanceof Object) {
            const jsonDate = data as StateType;
            if (data.country == "Select Country" && jsonDate.state == "") {
                customToast("Please fill all required fields state,country,status")
                return false;
            } else if (jsonDate.state == "") {
                customToast("Please Enter State Name");
                return false;
            } else if (data.country == "Select Country") {
                customToast("Please Select Country");
                return false;
            } else if (data.status == "Select Status") {
                customToast("Please Select Status");
                return false;
            } else {
                const countryObject: StateType = {
                    countryId: data.country,
                    state: jsonDate.state,
                    status: data.status == "Active" ? true : false
                }
                await onHttpPostRequset({
                    path: "/countries/create-state",
                    data: countryObject,
                    onSuccess: (response) => {
                        if (response.status == 200) {
                            onFetchState()
                            return true;
                        }
                    },
                    onError: (error) => {
                        if (error instanceof AxiosError) {
                            if (error.response != null) {
                                customToast(error.response.data.message);
                            } else {
                                customToast(error.message);
                            }
                        }
                        return false;
                    }
                })
                return true;
            }
        }
        return false;
    }
    const onCitySubmit = async (data: any) => {
        if (data instanceof Object) {
            const jsonDate = data as CityType;
            if (data.countryId == "Select Country" && data.stateId == "Select State" && jsonDate.city == "") {
                customToast("Please fill all required fielda city,state,country,status");
                return false;
            } else if (jsonDate.city == "") {
                customToast("Please Enter City Name");
                return false;
            } else if (data.countryId == "Select Country") {
                customToast("Please Select Country");
                return false;
            } else if (data.stateId == "Select State") {
                customToast("Please Select Status");
                return false;
            } else if (data.status == "Select Status") {
                customToast("Please Select Status");
                return false;
            } else {
                const countryObject: CityType = {
                    countryId: data.country,
                    stateId: data.state,
                    city: jsonDate.city,
                    status: data.status == "Active" ? true : false
                }
                await onHttpPostRequset({
                    path: "/countries/create-city",
                    data: countryObject,
                    onSuccess: (response) => {
                        if (response.status == 200) {
                            onFetchCity();
                            return true;
                        }
                    },
                    onError: (error) => {
                        if (error instanceof AxiosError) {
                            if (error.response != null) {
                                customToast(error.response.data.message);
                            } else {
                                customToast(error.message);
                            }
                        }
                        return false;
                    }
                })
                return true;
            }
        }
        return false;
    }
    const onAreaSubmit = async (data: any) => {
        if (data instanceof Object) {
            const jsonDate = data as AreaType;
            if (data.country == "Select Country" && data.state == "Select State" && data.city == "Select City" && jsonDate.area == "") {
                customToast("Please fill all required fielda area,city,state,country,status")
                return false;
            } else if (jsonDate.area == "") {
                customToast("Please Enter Area Name");
                return false;
            } else if (data.city == "Select City") {
                customToast("Please  Select City");
                return false;
            } else if (data.country == "Select Country") {
                customToast("Please Select Country");
                return false;
            } else if (data.state == "Select State") {
                customToast("Please Select Status");
                return false;
            } else if (data.status == "Select Status") {
                customToast("Please Select Status");
                return false;
            } else {
                const countryObject: AreaType = {
                    countryId: data.country,
                    stateId: data.state,
                    cityId: data.city,
                    area: jsonDate.area,
                    status: data.status == "Active" ? true : false
                }
                await onHttpPostRequset({
                    path: "/countries/create-area",
                    data: countryObject,
                    onSuccess: (response) => {
                        if (response.status == 200) {
                            onFetchArea()
                            return true;
                        }
                    },
                    onError: (error) => {
                        if (error instanceof AxiosError) {
                            if (error.response != null) {
                                customToast(error.response.data.message);
                            } else {
                                customToast(error.message);
                            }
                        }
                        return false;
                    }
                })
                return true;
            }
        }
        return false;
    }

    const onCategorySubmit = async (data: any) => {
        var isSuccess = false;
        if (data.title == "" && data.description == "") {
            customToast("Please fill all required fields title,description,status");
            return false;
        } else if (data.title == "") {
            customToast("Please Enter Title");
            return false;
        } else if (data.description == "") {
            customToast("Please Enter Description");
            return false;
        } else if (data.status == "Select Status") {
            customToast("Please Enter Status");
            return false;
        } else {
            await onHttpPostRequset({
                path: "/category/create",
                data: { title: data.title, description: data.description, status: data.status == "Active" ? true : false },
                onSuccess: (response) => {
                    if (response.status == 200) {
                        onFetchCategory();
                    }
                    isSuccess = true;
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                    isSuccess = false;
                }

            });
        }
        return isSuccess;
    }
    const onSubCategorySubmit = async (data: any) => {
        var isSuccess = false;
        if (data.title == "" && data.description == "") {
            customToast("Please fill all required fields title,description,status");
            return false;
        } else if (data.title == "") {
            customToast("Please Enter Title");
            return false;
        } else if (data.description == "") {
            customToast("Please Enter Description");
            return false;
        } else if (data.category == "") {
            customToast("Please Select Category");
            return false;
        } else if (data.status == "Select Status") {
            customToast("Please Enter Status");
            return false;
        } else {

            const jsonObject = { title: data.title, description: data.description, status: data.status == "Active" ? true : false, categoryId: data.category };
            console.log(jsonObject);
            await onHttpPostRequset({
                path: "/category/sub-category-create",
                data: jsonObject,
                onSuccess: (response) => {
                    console.log(response);
                    if (response.status == 200) {
                        onFetchSubCategory();
                    }
                    isSuccess = true;
                },
                onError: (error) => {
                    if (error instanceof AxiosError) {
                        if (error.response != null) {
                            customToast(error.response.data.message);
                        } else {
                            customToast(error.message);
                        }
                    }
                    isSuccess = false;
                }

            });
        }
        return isSuccess;
    }

    const customToast = (message: string) => {
        toast(message, {
            style: {
                background: '#111',
                color: "white",
            },
            progressStyle: {
                background: '#C0392B'
            },
        });
    }

    const onCreatePost = async (data: any): Promise<CraetedPostType> => {
        let result: CraetedPostType = {
            isSuccess: false,
            roomId: null
        };
        await onHttpPostRequset({
            data: data,
            path: "/post/create/",
            onSuccess: (response) => {
                console.log(response.data);
                if (response.status == 200) {
                    result.isSuccess = true;
                    result.roomId = response.data.data._id;
                }
            },
            onError: (error) => {
                if (error instanceof AxiosError) {
                    if (error.response != null) {
                        customToast(error.response.data.message);
                    } else {
                        customToast(error.message);
                    }
                }
                result.isSuccess = false;
                result.roomId = null;
            }
        });

        return result;
    }


    return <AppContext.Provider
        value={{
            onLoginEmail,
            onSignupEmail,
            localUser,
            setLocalUser,
            onLogout,
            adminLogin,
            adminRegister,
            onFetchUser,
            allFetchUsers,
            setAllFetchUsers,
            onFetchCountry,
            setAllFetchCountries,
            allFetchCountries,
            setAllFetchStates,
            allFetchStates,
            onSubmit,
            onCountrySubmit,
            onCategorySubmit,
            allFetchCategory,
            setAllFetchCategory,
            onSubCategorySubmit,
            allFetchSubCategory,
            setAllFetchSubCategory,
            menuCountry,
            setMenuCountry,
            menuTopics,
            setMenuTopics,
            customToast,
            onStateSubmit,
            onCitySubmit,
            onAreaSubmit,
            setAllFetchCites,
            allFetchCites,
            setAllFetchArea,
            allFetchArea,
            countryId,
            setCountryId,
            setStateId,
            stateId,
            onCreatePost,
            allPosts,
            setAllPosts
        }}>
        {children}
    </AppContext.Provider>
}

export { AppContext, AppContextProvider };
