import { Outlet } from "react-router-dom";
import Header from "./Components/Header/Header";
import "./App.css"
import SideBar from "./Components/Sidebar/SideBar";
export default function Root() {

    const onMenuClick = () => {
        if (document.getElementById("sideBar")?.style.getPropertyValue('left') === "0px") {
            document.getElementById("sideBar")!.style.left = "-100rem";
        } else {
            document.getElementById("sideBar")!.style.left = "0";

        }
    }
    return (
        <div className="main">
            <Header menuClick={onMenuClick}  />
            <div id="layoutBox">
                <SideBar />
                <Outlet />
            </div>
        </div>
    );
}
