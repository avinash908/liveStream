import { ArrowDownward, ArrowDropDown, ArrowUpward, Message, PlayCircle, Share, ViewColumn } from '@mui/icons-material';
import { useContext, useState } from 'react';
import Img1 from '../../Assets/Images/Blog_Cover.jpg';
import Img2 from '../../Assets/Images/img2.webp';
import Img3 from '../../Assets/Images/img3.webp';
import Img4 from '../../Assets/Images/img4.webp';
import UserProfile from '../../Assets/Images/userProfile.png';
import GoLiveModal from '../../Components/GoLiveModal/GoLiveModal';
import { useLiveStream } from '../../LiveSdk/Context/LiveStreamContext';
import LiveStream from '../../LiveSdk/LiveStream';
import { CraetedPostType } from '../../context/@Types/AppContextType';
import { AppContext } from '../../context/AppContext';
import './style.css';
// import Post2 from '../../Assets/Images/v.mp4';

interface UserType {
  id: string,
  name: string,
  image?: string,
}

interface TopicType {
  id: string,
  title: string,
  image?: string,
  shortDescription: string,
  author: UserType
}


const data: Array<TopicType> = [
  {
    id: "1",
    "title": "Burning",
    "shortDescription": "My Burning Man Ticket from 1996",
    "image": Img1,
    "author": {
      id: '1',
      "name": "r/BurningMan",
      "image": "https://a.thumbs.redditmedia.com/DA-fuKvYUgPSs_lJnbQ8aMn2Y75D6qtPD4oT5aZe2I4.png",
    }
  },
  {
    id: "2",
    "title": "Gamescom",
    "image": Img2,

    "shortDescription": "Risked my life getting a photo with Pro....",
    "author": {
      id: "2",
      "name": "r/HonkaiStarRail",
      "image": "https://styles.redditmedia.com/t5_4q5zoc/styles/communityIcon_3cf42puob36b1.png",
    }
  },
  {
    id: "3",
    "title": "FIBA World Cup",
    "image": Img3,

    "shortDescription": "[The Athletic] Shai Gilgeous-Alexander...",
    "author": {
      id: "3",
      "name": "r/nba",
      "image": "https://styles.redditmedia.com/t5_2qo4s/styles/communityIcon_1podsfdai4301.png",
    }
  },
  {
    id: "4",
    "title": "NFL Preseason",
    "shortDescription": "Liking What I'm Seeing From Love",
    "image": Img4,
    "author": {
      id: "4",
      "name": "r/GreenBayPackers",
      "image": "https://a.thumbs.redditmedia.com/fMlQyAzFSB0ka6F1JQ7fIvot7-3rdqJ2WZp8x-niEB4.png",
    }
  },
  {
    id: "3",
    "title": "FIBA World Cup",
    "image": Img3,

    "shortDescription": "[The Athletic] Shai Gilgeous-Alexander...",
    "author": {
      id: "3",
      "name": "r/nba",
      "image": "https://styles.redditmedia.com/t5_2qo4s/styles/communityIcon_1podsfdai4301.png",
    }
  },
  {
    id: "4",
    "title": "NFL Preseason",
    "shortDescription": "Liking What I'm Seeing From Love",
    "image": Img4,
    "author": {
      id: "4",
      "name": "r/GreenBayPackers",
      "image": "https://a.thumbs.redditmedia.com/fMlQyAzFSB0ka6F1JQ7fIvot7-3rdqJ2WZp8x-niEB4.png",
    }
  }
];





export const HomeScreen = () => {
  const [openModal, setOpenModal] = useState(false);
  const appContext = useContext(AppContext);
  const [isGoLive, setIsGoLive] = useState(false);
  const [isLoader, setIsLoader] = useState(false);
  const liveStream = useLiveStream();
  // useEffect(() => {
  //   Emitter.on("allLiveStream", ({ error, rooms }: any) => {
  //     if (error != null) {
  //       console.log(error.message);
  //     } else {
  //     }
  //   });
  // }, [])
  const onGoLive = async () => {
    setOpenModal(true);
  }
  const onCreatePost = async (data: any) => {
    if (data.postTitle == "" && data.postOrigin.countryId == "Select Country" && data.postTopic.categoryId == "Select Topic" && data.postThumbnail == "") {
      appContext?.customToast("Please Fill all required fields title,country,post thumbnail,topics");
    } else if (data.postTitle == "") {
      appContext?.customToast("Please Enter Post Title");
    } else if (data.postOrigin.countryId == "Select Country") {
      appContext?.customToast("Please Select Country");
    } else if (data.postTopic.categoryId == "Select Topic") {
      appContext?.customToast("Please Select Topic");
    } else if (data.postThumbnail == "Select Topic") {
      appContext?.customToast("Please Upload post thumbnail");
    } else {
      setIsLoader(true);
      const result: CraetedPostType | undefined = await appContext?.onCreatePost!(data);
      if (result == undefined) {
        appContext?.customToast("Please Reload The  Web Page");
      } else {
        if (result.isSuccess) {
          const userData = {
            name: appContext?.localUser.username,
            id: appContext?.localUser._id,
          }
          await liveStream?.onLogin!(userData);
          await liveStream?.onCreateRoom!(result.roomId!, async (error, joindRoomId) => {
            if (error != null) {
              appContext?.customToast!(error.message);
            } else {
              await liveStream.onJoin!(joindRoomId!, { isAdmin: true });
            }
          });
          setIsGoLive(result.isSuccess);
        }
      }
      setOpenModal(false);
      setIsLoader(false);
    }
  }





  const onPlayStream = async (id: string) => {
    if (appContext?.localUser == null) {
      appContext?.customToast!("Please Login To Go Live");
    } else {
      const data = {
        name: appContext.localUser.username,
        id: appContext.localUser._id,
      }
      await liveStream?.onLogin!(data);
      setIsGoLive(true);
      await liveStream?.onJoin!(id, { isAdmin: false });
    }
  }

  return (
    <>
      {
        isGoLive ?
          <LiveStream
            liveStreamConfig={{ serverKey: "demoKey", appId: "3253645" }}
            user={{ name: "name", id: "userId" }}
          /> :
          <div className="mainHome">
            {/* <div className='topics'>
              {
                data.map((v: TopicType, index: number) => {
                  return <div key={index} className='card1'>
                    <img src={v.image} ></img>
                    <div className='cardBody'>
                      <h1>{v.title}</h1>
                      <p>{v.shortDescription}</p>
                      <div className='author' key={v.author.id}>
                        <img src={v.author.image} />
                        <p>{v.author.name}</p>
                        <span>and more</span>
                      </div>
                    </div>
                  </div>
                })
              }
            </div> */}
            <div className='postDive'>
              <div className='posts'>
                <div className='meUserDiv'>
                  <div onClick={onGoLive} className="create-post">
                    <img src="https://www.redditstatic.com/shreddit/assets/snoovatar-snoo.png" />
                    <span>Go Live</span>
                  </div>
                  <div className='option'>
                    <span>Hot <ArrowDropDown /></span>
                    <span>Everyone <ArrowDropDown /></span>
                    <span><ViewColumn /> <ArrowDropDown /></span>
                  </div>
                </div>
                <div style={{ marginTop: 20 }}>
                  {
                    appContext?.allPosts == null ? <p style={{ textAlign: 'center', color: "#fff", paddingBlock: 20 }}>Please Wait...</p> :
                      appContext?.allPosts.length > 0 ?
                        appContext?.allPosts?.map((v, index) => {
                          console.log(v)
                          return <div key={index} className='postCard'>
                            <div className='postHeader' style={{ display: 'flex' }}>
                              <div className='author' >
                                <img src={UserProfile} />
                                <p>{v.user?.username}</p>
                              </div>
                              <div>{
                                v.isLive && <p style={{
                                  border: '1px solid red',
                                  paddingInline: "14px",
                                  color: '#fff',
                                  fontWeight: 600,
                                  borderRadius: "4px",
                                }}>Live</p>
                              }</div>
                            </div>
                            <div className='postBody'>
                              <p>{v.postTitle}</p>
                              {v.recordedUrl !== "" ?
                                <video poster={v.postThumbnail} controls>
                                  <source src={v.recordedUrl} type='video/webm'></source>
                                </video>
                                // <ReactPlayer  controls width={600} url={v.recordedUrl} />
                                :
                                <div>

                                  {v.postThumbnail && <div style={{ position: "relative" }}>
                                    <img src={v.postThumbnail} />
                                    <div className='playBtnDiv'>
                                      <PlayCircle onClick={() => { v.isLive ? onPlayStream(v._id) : appContext?.customToast!("You can not play the stream") }} style={{ fontSize: 50, color: "#fff", cursor: "pointer" }} />
                                    </div>
                                  </div>}
                                </div>
                              }
                            </div>
                            <div className="postFooter" style={{ marginTop: 10 }}>
                              <button>
                                <ArrowUpward />
                                <span>48k</span>
                                <ArrowDownward />
                              </button>
                              <button>
                                <Message />
                                <span>717</span>
                              </button>
                              <button>
                                <Share />
                                <span>Share</span>
                              </button>
                            </div>
                            <hr style={{ background: "#777" }} />
                          </div>
                        })
                        : <p style={{ textAlign: 'center', color: "#fff", paddingBlock: 20 }}>No Post Live Or Recorded</p>
                  }
                </div>
              </div>
              <div className="members"></div>
            </div>
          </div >}
      <GoLiveModal
        title='Go Live'
        open={openModal}
        onClose={() => setOpenModal(false)}
        onSubmit={onCreatePost}
        isLoader={isLoader}
      />
    </>
  )
}


export default HomeScreen;