import './style.css';

import { useEffect, useState } from 'react';
import { LiveStreamType, MediaType } from './@Types/LiveStreamTypes';
import { LocalStream } from './Context/@Types/LiveStreamType';
import { useLiveStream } from './Context/LiveStreamContext';
import Emitter from './LiveStreamEvent';


const SRVERKEY = "demoKey";
const APPID = "3253645";

function LiveStream({ liveStreamConfig, user }: LiveStreamType) {
    const [videos, setVideos] = useState<Array<LocalStream> | null>([]);
    const [requsetData, setRequsetData] = useState<any | null>(null);

    const liveStreamContext = useLiveStream();
    useEffect(() => {
        if (liveStreamConfig.serverKey != SRVERKEY || liveStreamConfig.appId != APPID) {
            throw "Your Server key or app id not valid";
        } else {
            onInitLiveStram();
        }
    }, [liveStreamConfig])



    const onInitLiveStram = () => {
        Emitter.on("localVideoStream", (data: LocalStream) => {
            onRemoteVideo(data);
            // setVideos(e => [...e!, { peerId: data.peerId, stream: data.stream, socketId: data.socketId }]);
            // console.log(videos);
        });
        Emitter.on("remoteVideoStream", (data: LocalStream) => {
            onRemoteVideo(data);
        });
        Emitter.on("requsetToJoin", (data: any) => {
            setRequsetData(data);
        });
        // });
    }

    const onRemoteVideo = (data: LocalStream) => {
        var video = videos;
        if (video!.filter((v) => v.socketId === data.socketId).length <= 0) {
            setVideos(e => [...e!, { peerId: data.peerId, stream: data.stream, socketId: data.socketId }]);
        }
        console.log(video);
    }




    const onEndLive = async () => {
        await liveStreamContext?.closeProducer!(MediaType.VIDEO);
        await liveStreamContext?.closeProducer!(MediaType.AUDIO);
    }


    const onRequest = () => {
        liveStreamContext?.onRequsetSend!();
    }

    const onAccept = (id: string) => {
        liveStreamContext?.makeAdmin!(id);
        setRequsetData(null);
    }
    const onReject = () => {
        setRequsetData(null);
    }
    return (
        <div className='liveStream'>
            <div className='liveStream-liveBox'>
                <div className='videoGrid' id='videoGrid'>
                    <p className="live-btn">Live</p>

                    {/* <div id='video-list'> */}
                    {
                        liveStreamContext!.videoStreams.current!.size <= 0 ? <p color='#111'>Please Wait..</p> :
                            Array.from(liveStreamContext?.videoStreams.current?.keys()!).map((v, k) => {
                                console.log(v);
                                const stream = liveStreamContext?.videoStreams.current?.get(v);
                                return <div key={k}
                                    id={`video-box-${stream?.peerId}`}
                                    className={`${liveStreamContext!.videoStreams.current!.size == 1 ? 'video-box' :
                                        liveStreamContext!.videoStreams.current!.size == 2 ? "video-box-tow" : "video-box-three"}`}>
                                    <VideoPlayer stream={stream!.stream} peerId={stream!.peerId} socketId={stream!.socketId} />
                                </div>
                            })
                    }
                    {/* </div> */}


                    <div className="notificationBox" style={{ display: requsetData != null ? "block" : 'none' }}>
                        <p>user id:{requsetData && requsetData!.id}</p>
                        <p>{requsetData && requsetData!.name}</p>
                        <div>
                            <button onClick={onReject}>Reject</button>
                            <button onClick={() => onAccept(requsetData && requsetData!.id)}>Accept</button>
                        </div>
                    </div>
                </div>
                <div className='audio' style={{ display: "none" }} >
                    {
                        liveStreamContext!.audioStreams.current!.size <= 0 ? <p color='#111'>Please Wait...</p> :
                            Array.from(liveStreamContext?.audioStreams.current?.keys()!).map((v, k) => {
                                console.log(v);
                                const stream = liveStreamContext?.audioStreams.current?.get(v);
                                return <div key={k}
                                    id={`audio-box-${stream?.peerId}`}>
                                    <AudioPlayer stream={stream!.stream} peerId={stream!.peerId} socketId={stream!.socketId} />
                                </div>
                            })
                    }
                </div>
                <div className='liveStream-actionBox'>
                    {liveStreamContext?.isAdmin ? null : <button className='requestBtn' onClick={liveStreamContext?.isRequset ? () => { } : onRequest}>{liveStreamContext?.isRequset ? "Requesting..." : "Request To Join"}</button>}
                    <button className='endBtn' onClick={onEndLive}>End Live</button>
                </div>
            </div>
            <div className='liveStream-message'>

            </div>
        </div>
    )
}


const VideoPlayer = ({ stream, peerId, socketId }: LocalStream) => {
    useEffect(() => {
        const video = document.getElementById(`video-${peerId}`) as HTMLVideoElement;
        video.srcObject = stream;
        video.playsInline = true;
        video.play();

    }, [peerId]);
    return <video style={{
        width: "100%",
        height: "100%",
        objectFit: "fill",
        borderRadius: 10
    }} className='localVideo' id={`video-${peerId}`}>
    </video>
}

const AudioPlayer = ({ stream, peerId, socketId }: LocalStream) => {
    useEffect(() => {
        const video = document.getElementById(`audio-${peerId}`) as HTMLAudioElement;
        video.srcObject = stream;
        video.play();

    }, [peerId]);
    return <audio id={`audio-${peerId}`}>
    </audio>
}

export default LiveStream