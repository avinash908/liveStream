import React from 'react'

function LiveStreamVideo() {
    return (
        <div>LiveStreamVideo</div>
    )
}

export default LiveStreamVideo