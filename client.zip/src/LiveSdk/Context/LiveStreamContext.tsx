import { Device, types } from 'mediasoup-client';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { MediaType, User } from '../@Types/LiveStreamTypes';
import Emitter from '../LiveStreamEvent';
import { socket } from '../socket';
import { JoinRoomOption, LiveStreamType, LocalStream } from './@Types/LiveStreamType';
import { screenShare } from './recoding';

interface RtpCapabilitiesType {
    routerRtpCapabilities: types.RtpCapabilities,
    id: string,
}
let isSuperAdmin = false;
const LiveStreamContext = createContext<LiveStreamType | null>(null);
const LiveStreamContextProvider = ({ children }: any) => {
    const [name, setName] = useState<string>('');
    const [user, setUser] = useState<User | null>(null);
    const [userId, setUserId] = useState<string>('');
    const [roomId, setRoomId] = useState<string>("");
    const [joindRoomId, setJoindRoomId] = useState<string>("");
    const [superAdmin, setSuperAdmin] = useState(false);
    const [joinId, setJoinId] = useState<string>('');
    const [loggedin, setLoggedIn] = useState(false);
    const device = React.useRef<types.Device | null>(null);
    const producerTransport = React.useRef<types.Transport | null>(null);
    const consumerTransport = React.useRef<types.Transport | null>(null);
    const consumersStream = React.useRef<Map<string, types.Consumer>>(new Map());
    const produsers = React.useRef<Map<string, types.Producer>>(new Map());
    const producersLabel = React.useRef<Map<string, string>>(new Map());
    const videoStreams = React.useRef<Map<string, LocalStream>>(new Map());
    const audioStreams = React.useRef<Map<string, LocalStream>>(new Map());
    const localStream = React.useRef<MediaStream | null>(null);
    const [isAdmin, setIsAdmin] = useState(false);
    const [isRequset, setIsRequset] = useState(false);

    function sendRequest(type: any, data: any) {
        return new Promise((resolve: any, reject: any) => {
            socket.emit(type, data, (err: any, response: any) => {
                if (!err) {
                    resolve(response);
                } else {
                    reject(err);
                }
            });
        });

    }

    useEffect(() => {
        socket.emit("getAllRooms", {});
        socket.on("allRooms", (data) => {
            console.log(data);
            if (data == null) {
                Emitter.emit("allLiveStream", { error: { message: "Room Not Founded" }, rooms: null });
            } else {
                const rooms = JSON.parse(data);
                console.log(rooms);
                Emitter.emit("allLiveStream", { error: null, rooms: rooms });
            }
        });
    }, []);
    const onLogin = async (user: User) => {
        setName(user.name);
        setUserId(user.id);
        setUser({
            id: user.id,
            name: user.name
        });
        await saveLocaUser({ name: user.name, id: user.id });
        socket.emit("userLogin", { name: user.name, userId: user.id }, async (isLogin: boolean) => {
            setLoggedIn(true);
        });
    }



    const saveLocaUser = async ({ name, id }: any) => {
        window.localStorage.setItem("@user", JSON.stringify({ name, id }));
        return true;
    }

    const onCreateRoom = async (roomId1: string, cb: (error: any, id: string | null) => void) => {
        var user1 = window.localStorage.getItem('@user');
        setRoomId(roomId1);
        isSuperAdmin = true;
        if (user != null || user1 != null) {
            var newUser = JSON.parse(user1!);
            socket.emit("createRoom", { roomId: roomId1, userId: user1 == null ? user?.id : newUser.id }, (data: any) => {
                if (data.isCreated) {
                    cb(null, roomId1);
                } else {
                    cb({
                        message: "Room is Already Created...",
                    }, null)
                }
            });
        } else {
            alert("Please Reload Web Page");
        }
    }
    const onJoin = async (roomId: string, { isAdmin }: JoinRoomOption) => {
        setJoinId(roomId);
        setIsAdmin(isAdmin);
        var user = window.localStorage.getItem('@user');
        if (user !== null) {
            var newUser = JSON.parse(user);
            window.localStorage.setItem('@isAdmin', JSON.stringify(isAdmin));
            socket.emit('join', { roomId: roomId, name: newUser.name, isAdmin: isAdmin }, onJoinRoom);
        }
    }
    const onJoinRoom = async (error: any, result: any) => {
        if (error !== null) {
            alert(error.message);
        } else {
            setJoindRoomId(result.id);
            socket.emit("getRouterRtpCapabilities", { id: result.id }, async (error: any, { routerRtpCapabilities, id }: RtpCapabilitiesType) => {
                if (error !== null) {
                    alert("Please Try agian");
                    return;
                } else {
                    await loadDevices(routerRtpCapabilities);
                    const { id, params }: any = await sendRequest('createWebRtcTransport', {
                        id: result.id
                    });
                    console.log('transport params:', params);
                    producerTransport.current = device.current?.createSendTransport(params)!;
                    producerTransport.current.on(
                        'connect',
                        async ({ dtlsParameters }: any, callback: any, errback: any) => {
                            console.log('--trasnport connect');
                            await sendRequest('connectTransport', {
                                transportId: producerTransport.current!.id,
                                dtlsParameters: dtlsParameters,
                                id: result.id
                            })
                                .then(callback)
                                .catch(errback);
                        }
                    );
                    producerTransport.current.on(
                        'produce',
                        async (
                            { kind, rtpParameters, appData }: any,
                            callback: any,
                            errback: any
                        ) => {
                            console.log('--trasnport produce', appData);
                            try {
                                const { id }: any = await sendRequest('produce', {
                                    producerTransportId: producerTransport.current!.id,
                                    kind,
                                    rtpParameters,
                                    id: result.id,
                                    appData
                                });
                                callback({ id });
                                console.log('--produce requested, then subscribe ---');
                            } catch (err) {
                                errback(err);
                            }
                        }
                    );
                    producerTransport.current.on('connectionstatechange', (state: any) => {
                        switch (state) {
                            case 'connecting':
                                console.log('publishing...');
                                break;

                            case 'connected':
                                console.log('published');
                                //  setIsConnected(true);
                                break;

                            case 'failed':
                                console.log('failed');
                                producerTransport.current?.close();
                                break;

                            default:
                                break;
                        }
                    });
                    if (result.isAdmin) {
                        await produce(MediaType.AUDIO);
                        await produce(MediaType.VIDEO);
                    }
                    await initConsumerTransport(result.id);
                    socket.emit('getProducers', { id: result.id });
                }
            });
        }
        initSokcet();
    }



    const getMediaConstraints = (type: MediaType, deviceId?: string) => {
        if (type === MediaType.AUDIO) {
            return {
                audio: {
                    deviceId: deviceId,
                },
                video: false,
            };
        } else if (type === MediaType.VIDEO) {
            return {
                audio: false,
                video: {
                    width: {
                        min: 640,
                        ideal: 1920,
                    },
                    height: {
                        min: 400,
                        ideal: 1080,
                    },
                    deviceId: deviceId,
                },
            };
        }
    }



    const produce = async (type: MediaType, deviceId?: string) => {
        const mediaConstraints = getMediaConstraints(type, deviceId);
        if (producersLabel.current.has(type)) {
            console.log(`Producer already exists for this type: ${type}`);
        }
        console.log('Mediaconstraints', mediaConstraints);
        let stream: MediaStream | null = null;
        try {
            // if (type === MediaType.SCREEN) {
            //     stream = await screenShare();
            // }
            if (type === MediaType.SCREEN) {
                stream = await screenShare();
            } else {
                stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
            }
        } catch (e) {
            console.error(`Failed to open media: ${type}`);
        }
        if (!stream) {
            console.error(`Failed to open stream`);
            return;
        }
        const track =
            type === MediaType.AUDIO
                ? stream.getAudioTracks()[0]
                : stream.getVideoTracks()[0];

        const params =
            type === MediaType.VIDEO
                ? {
                    track,
                    encodings: [
                        {
                            maxBitrate: 100000,
                            // maxFramerate: 15.0,
                            // scaleResolutionDownBy: 1.5,
                        },
                        {
                            maxBitrate: 300000,
                        },
                        {
                            maxBitrate: 900000,
                        },
                    ],
                    codecOptions: {
                        videoGoogleStartBitrate: 1000,
                    },
                }
                : {
                    track,
                };

        console.log(`> producer params`, params);
        const producer = await producerTransport.current?.produce({
            ...params,
            appData: { type: type === MediaType.SCREEN ? "scree-share" : "video" }
        });
        if (!producer) {
            console.error(`Failed to create producer`);
            return;
        }
        produsers.current?.set(producer.id, producer);
        producer.on('trackended', () => {
            console.log('producer closed');
            closeProducer(type);
        });
        producer.on('transportclose', () => {
            console.log("videoStreams.current.get(socket.id)");
            if (videoStreams.current.has(socket.id)) {
                var data: LocalStream = videoStreams.current.get(socket.id)!;
                document.getElementById("video-box-" + data.peerId)?.remove();
                videoStreams.current.delete(socket.id);
            }
            produsers.current.delete(producer.id);
        });
        producer.on("@close", () => {
            console.log("videoStreams.current.get(socket.id)");
            if (videoStreams.current.has(socket.id)) {
                var data: LocalStream = videoStreams.current.get(socket.id)!;
                const elem1 = document.getElementById('video-' + data.peerId) as HTMLVideoElement;
                const elem = document.getElementById('video-box-' + data.peerId) as HTMLDivElement;
                elem?.removeChild(elem1);
                elem?.remove();
                videoStreams.current.delete(socket.id);
            }
            if (audioStreams.current.has(socket.id)) {
                var data: LocalStream = audioStreams.current.get(socket.id)!;
                const elemAudio1 = document.getElementById('audio-' + data.peerId) as HTMLVideoElement;
                const elemAudioBox = document.getElementById('audio-box-' + data.peerId) as HTMLDivElement;
                elemAudioBox?.removeChild(elemAudio1);
                elemAudioBox?.remove();
                audioStreams.current.delete(socket.id);
            }
        });
        producersLabel.current.set(type, producer.id);
    }




    const produceRecodrd = async (type: "screen-audio" | "screen-video", stream: any) => {
        if (producersLabel.current.has(type)) {
            console.log(`Producer already exists for this type: ${type}`);
        }
        // let stream: MediaStream | null = null;
        // try {
        //     stream = await screenShare();
        // } catch (e) {
        //     console.error(`Failed to open media: ${type}`);
        // }
        // if (!stream) {
        //     console.error(`Failed to open stream`);
        //     return;
        // }
        const track =
            type === "screen-audio"
                ? stream
                : stream;

        const params =
            type === "screen-video"
                ? {
                    track,
                    encodings: [
                        {
                            maxBitrate: 100000,
                            // maxFramerate: 15.0,
                            // scaleResolutionDownBy: 1.5,
                        },
                        {
                            maxBitrate: 300000,
                        },
                        {
                            maxBitrate: 900000,
                        },
                    ],
                    codecOptions: {
                        videoGoogleStartBitrate: 1000,
                    },
                }
                : {
                    track,
                };

        console.log(`> producer params`, params);
        const producer = await producerTransport.current?.produce({
            ...params,
            appData: { type: "scree-share" }
        });
        if (!producer) {
            console.error(`Failed to create producer`);
            return;
        }
        produsers.current?.set(producer.id, producer);
        producersLabel.current.set(type, producer.id);
    }










    async function initSokcet() {
        socket.on('newProducers', async (data) => {
            console.log(`New producers`, data);
            for (const produce of data.producerList) {
                await consume(produce.producer_id, data.id, produce.producer_socket_id);
            }
        });

        socket.on("requsetToJoin", (data) => {
            Emitter.emit("requsetToJoin", data);
            console.log("requset=>", data);

        });

        socket.on("requsetAccepted", async ({ isAdmin, roomId1 }) => {
            if (isAdmin) {
                setIsRequset(false);
                setIsAdmin(isAdmin);
                await produce(MediaType.VIDEO);
                await produce(MediaType.AUDIO);
                await initConsumerTransport(roomId1);
                socket.emit('getProducers', { id: roomId1 });
            }
        });
        socket.on("consumerClosed", (data) => {
            removeConsumer(data.consumer_id, data.socketId, data.consumer_kind)
        });
        socket.on("liveEnded", (_) => {
            window.location.reload();
        })
    }

    async function initConsumerTransport(roomId: string) {
        if (!device.current) {
            return;
        }
        const { id, params }: any = await sendRequest('createWebRtcTransport', {
            id: roomId,

        });
        consumerTransport.current = device.current.createRecvTransport(params);
        consumerTransport.current.on('connect', async (data: any, callback: any, errback: any) => {
            // try {
            await sendRequest('connectTransport', {
                transportId: consumerTransport.current!.id,
                dtlsParameters: data.dtlsParameters,
                id: roomId,
            }).then(callback).catch(errback);
            // callback();
            // } catch (e: any) {
            //     console.error(e);
            //     errback(e);
            // }
        });


        consumerTransport.current.on('connectionstatechange', async (state: types.ConnectionState) => {
            console.log(`>> consumer transport state changed`, state);
            if (state === 'failed') {
                console.log("Connection failed by consumer")
                consumerTransport.current?.close();
                // window.location.reload();
            } else if (state === "disconnected") {
                console.log("Connection disconnected by consumer")

                consumerTransport.current?.close();
                // window.location.reload();
            } else if (state === "connected") {
                if (isSuperAdmin) {
                    console.log("okkkkkkd");
                    const stream = await screenShare();
                    if (stream.getAudioTracks()[0] != null) {
                        const audioStream = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
                        if (audioStream.getAudioTracks()[0]) {
                            await produceRecodrd("screen-audio", audioStream.getAudioTracks()[0]);
                        }
                    }
                    if (stream.getVideoTracks()[0] != null) {
                        await produceRecodrd("screen-video", stream.getVideoTracks()[0]);
                    }
                    setTimeout(() => {
                        socket.emit("startRecording", {});
                    }, 5000)
                }
            }
        });
        consumerTransport.current.on(
            'icegatheringstatechange',
            (state) => {
                console.log('Consumer icegatheringstatechange', state);
            },
        );

    }
    async function consume(producerId: string, roomId: string, producer_socket_id: string) {
        const stream = await getConsumeStream(producerId, roomId, producer_socket_id);
        if (!stream) {
            console.error(`Failed to consume ${producerId}`);
            return;
        }
        if (producer_socket_id == socket.id && stream.appData.type == "video") {
            if (stream.kind == "video") {
                console.log("server id" + socket.id);
                Emitter.emit("localVideoStream", {
                    peerId: stream.consumer.id,
                    stream: stream.stream,
                    socketId: socket.id,
                });
                videoStreams.current.set(producer_socket_id, {
                    socketId: producer_socket_id,
                    stream: stream.stream,
                    peerId: stream.consumer.id
                });
                // return;
            } else if (stream.kind == "audio") {
                Emitter.emit("localAudioStream", {
                    peerId: stream.consumer.id,
                    stream: stream.stream,
                    socketId: socket.id,
                });
                audioStreams.current.set(producer_socket_id, {
                    socketId: producer_socket_id,
                    stream: stream.stream,
                    peerId: stream.consumer.id
                });
            }
            // if (superAdmin) {
            // }
        } else {
            if (stream.kind == "video" && stream.appData.type == "video") {
                Emitter.emit("remoteVideoStream", {
                    peerId: stream.consumer.id,
                    stream: stream.stream,
                    socketId: producer_socket_id
                });
                videoStreams.current.set(producer_socket_id, {
                    socketId: producer_socket_id,
                    stream: stream.stream,
                    peerId: stream.consumer.id
                });
            } else if (stream.kind == "audio" && stream.appData.type == "video") {
                Emitter.emit("remoteAudioStream", {
                    peerId: stream.consumer.id,
                    stream: stream.stream,
                    socketId: producer_socket_id
                });
                audioStreams.current.set(producer_socket_id, {
                    socketId: producer_socket_id,
                    stream: stream.stream,
                    peerId: stream.consumer.id
                });
            }
        }
        consumersStream.current?.set(stream.consumer.id, stream.consumer);
        stream.consumer.on('trackended', () => {
            console.log("no video avilbel");
            removeConsumer(stream.consumer.id, producer_socket_id, stream.kind);
        });

        stream.consumer.on('transportclose', () => {
            console.log("Close connection");
            removeConsumer(stream.consumer.id, producer_socket_id, stream.kind);
        });
        stream.consumer.on("@close", () => {
            console.log("Consumersgd");
        });
    }
    // const stre = await   screenShare();
    // console.log(stre);
    async function getConsumeStream(producerId: string, roomId: string, producer_socket_id: string) {
        if (!device.current || !consumerTransport.current) {
            return;
        }
        const { rtpCapabilities } = device.current;
        const data = await sendRequest('consume', {
            rtpCapabilities,
            consumerTransportId: consumerTransport.current.id,
            producerId,
            roomId,
            id: producer_socket_id
        });
        const { id, kind, rtpParameters, appData }: any = data;
        const consumer = await consumerTransport.current.consume({
            id,
            producerId,
            kind,
            rtpParameters,
            appData: appData
        });
        const stream = new MediaStream();
        stream.addTrack(consumer.track);
        return {
            consumer,
            stream,
            kind,
            producerId,
            appData
        };
    }




    const loadDevices = async (routerRtpCapabilities: types.RtpCapabilities) => {
        try {
            device.current = new Device();
        } catch (error: any) {
            if (error.name === 'UnsupportedError') {
                console.error('browser not supported');
            }
        }
        await device.current?.load({ routerRtpCapabilities });
    }




    const closeProducer = async (type: MediaType) => {
        const producerId = producersLabel.current.get(type);
        console.log(producerId);
        if (!producerId) {
            console.log(`There is no producer for this type: ${type}`);
            return;
        };
        produsers.current.get(producerId)?.close();
        produsers.current.delete(producerId);
        producersLabel.current.delete(type);

        const isAdmin = window.localStorage.getItem("@isAdmin");
        if (isAdmin != null) {
            var admin: boolean = JSON.parse(isAdmin);
            if (admin) {
                // socket.emit("stopRecording", {})
                socket.emit("liveEnd", {}, (data: any) => {
                    console.log(data);
                    window.location.reload();
                });
            } else {
                sendRequest('producerClosed', {
                    producer_id: producerId,
                });
                window.location.reload();
            }
        }

    }


    const removeConsumer = (consumerId: string, socketId: string, consumer_kind: string) => {
        const elem1 = document.getElementById('video-' + consumerId) as HTMLVideoElement;
        const elem = document.getElementById('video-box-' + consumerId) as HTMLDivElement;
        elem?.removeChild(elem1);
        elem?.remove();
        videoStreams.current.delete(socketId);
        if (consumer_kind == "audio") {
            const elemAudio1 = document.getElementById('audio-' + consumerId) as HTMLVideoElement;
            const elemAudioBox = document.getElementById('audio-box-' + consumerId) as HTMLDivElement;
            elemAudioBox?.removeChild(elemAudio1);
            elemAudioBox?.remove();
            audioStreams.current.delete(socketId);
        }
        consumersStream.current!.delete(consumerId);
    }
    const onRequsetSend = () => {
        setIsRequset(true);
        socket.emit("sendRequsetToJoin", {});
    }
    const makeAdmin = (id: string) => {
        socket.emit("requsetAccept", id);
    }





    return <LiveStreamContext.Provider
        value={{
            name,
            setName,
            onLogin,
            loggedin,
            setLoggedIn,
            roomId,
            setRoomId,
            joinId,
            setJoinId,
            onCreateRoom,
            onJoin,
            setJoindRoomId,
            joindRoomId,
            setUserId,
            userId,
            closeProducer,
            onRequsetSend,
            makeAdmin,
            videoStreams,
            audioStreams,
            isAdmin,
            setIsAdmin,
            isRequset,
            setIsRequset
        }}
    >
        {children}
    </LiveStreamContext.Provider>
}

export const useLiveStream = () => useContext<LiveStreamType | null>(LiveStreamContext);

export { LiveStreamContextProvider };
