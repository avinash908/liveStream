import React from 'react';
import { MediaType, User } from '../../@Types/LiveStreamTypes';



export interface LocalStream {
  stream: MediaStream,
  peerId: string,
  socketId:string
}


export interface JoinRoomOption {
  isAdmin: boolean,
}

export interface LiveStreamType {
  name?: string,
  setName?: React.Dispatch<React.SetStateAction<string>>,
  isAdmin?: boolean,
  setIsAdmin?: React.Dispatch<React.SetStateAction<boolean>>,
  isRequset?: boolean,
  setIsRequset?: React.Dispatch<React.SetStateAction<boolean>>,
  userId?: string,
  setUserId?: React.Dispatch<React.SetStateAction<string>>,
  roomId?: string,
  setRoomId?: React.Dispatch<React.SetStateAction<string>>,
  joindRoomId?: string,
  setJoindRoomId?: React.Dispatch<React.SetStateAction<string>>,
  joinId?: string,
  setJoinId?: React.Dispatch<React.SetStateAction<string>>,
  loggedin?: boolean,
  setLoggedIn?: React.Dispatch<React.SetStateAction<boolean>>,
  onLogin?: (user: User) => Promise<void>,
  onCreateRoom?: (roomId: string, cb: (error: { message: string } | null, id: string | null) => void) => Promise<void>,
  onJoin?: (roomId: string, roomOption: JoinRoomOption) => Promise<void>,
  closeProducer?: (type: MediaType) => Promise<void>,
  onRequsetSend?:()=>void,
  makeAdmin?:(id:string)=>void,
  videoStreams:React.MutableRefObject<Map<string,LocalStream> | null>,
  audioStreams:React.MutableRefObject<Map<string,LocalStream> | null>,
  
}



