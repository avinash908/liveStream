export const screenShare = async () => {
    const stream = await navigator.mediaDevices.getDisplayMedia({
        preferCurrentTab: true, video: {
            displaySurface: "window"
        },
        audio: {
            echoCancellation: true,
            noiseSuppression: true,
            sampleRate: 44100,
          },
    });
    const [track] = stream.getVideoTracks();
    const mainContentArea = document.querySelector("#videoGrid");
    if ("CropTarget" in window && "fromElement" in window.CropTarget) {
        const cropTarget = await window.CropTarget.fromElement(mainContentArea)
        console.log(cropTarget);
        if (track.cropTo) {
            track.cropTo(cropTarget)
            console.log("track");
        }
    }
    return stream;
}