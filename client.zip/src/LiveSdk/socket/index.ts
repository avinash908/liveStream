import { io } from 'socket.io-client';

const URL = 'https://3.85.47.74:4100/';

export const socket = io(URL);


