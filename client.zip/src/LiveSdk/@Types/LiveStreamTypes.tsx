



export interface LiveStreamConfig {
    serverKey: string,
    appId: string,
}


export interface User {
    id: string,
    peerId?: string,
    name: string,
    email?: string,
    image?: string
}

export interface LiveStreamType {
    liveStreamConfig: LiveStreamConfig,
    user: User
}

export enum MediaType {
    VIDEO = 'video',
    AUDIO = 'audio',
    SCREEN = 'screen',
}

